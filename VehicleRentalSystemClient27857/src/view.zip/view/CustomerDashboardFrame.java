package view;

import view.util.*;
import controller.ClientRegistry;
import model.*;
import service.*;

import java.awt.*;
import java.awt.event.*;
import java.rmi.registry.Registry;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

/**
 * CustomerDashboardFrame - Premium customer portal dashboard.
 * Mirrors the admin architecture: sidebar + topbar + CardLayout content area.
 */
public class CustomerDashboardFrame extends javax.swing.JFrame {

    private final User currentUser;
    private SidebarPanel sidebar;
    private TopBar topBar;
    private JPanel contentArea;
    private CardLayout cardLayout;

    private static final String PAGE_HOME     = "home";
    private static final String PAGE_VEHICLES = "vehicles";
    private static final String PAGE_RENTALS  = "myrentals";
    private static final String PAGE_PAYMENTS = "mypayments";
    private static final String PAGE_PROFILE  = "profile";

    public CustomerDashboardFrame(User user) {
        this.currentUser = user;
        AppTheme.applyGlobalDefaults();
        setTitle("VRS — Customer Portal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 800);
        setMinimumSize(new Dimension(1050, 680));
        setLocationRelativeTo(null);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.CONTENT_BG);

        // ── SIDEBAR ─────────────────────────────────────────────────────────────
        sidebar = new SidebarPanel();
        sidebar.setProfileName(currentUser.getFullName());
        sidebar.setProfileRole("Customer Account");

        sidebar.addSectionLabel("PORTAL");
        SidebarPanel.SidebarItem homeItem = sidebar.addMenuItem("🏠", "My Dashboard",    e -> showPage(PAGE_HOME, "My Dashboard"));
        sidebar.addSectionLabel("RENTALS");
        sidebar.addMenuItem("🚗", "Browse Vehicles",  e -> showPage(PAGE_VEHICLES, "Browse Vehicles"));
        sidebar.addMenuItem("📋", "My Rentals",       e -> showPage(PAGE_RENTALS,  "My Rentals"));
        sidebar.addSectionLabel("FINANCE");
        sidebar.addMenuItem("💳", "Payment History",  e -> showPage(PAGE_PAYMENTS, "Payment History"));
        sidebar.addSeparator();
        sidebar.addMenuItem("👤", "My Profile",       e -> showPage(PAGE_PROFILE,  "My Profile"));
        sidebar.addMenuItem("🔒", "Logout",           e -> doLogout());

        sidebar.setActiveItem(homeItem);

        // ── TOP BAR ─────────────────────────────────────────────────────────────
        topBar = new TopBar("My Dashboard");

        // ── CONTENT AREA ────────────────────────────────────────────────────────
        cardLayout  = new CardLayout();
        contentArea = new JPanel(cardLayout);
        contentArea.setBackground(AppTheme.CONTENT_BG);

        contentArea.add(buildHomePage(),     PAGE_HOME);
        contentArea.add(new BrowseVehiclesPanel(currentUser), PAGE_VEHICLES);
        contentArea.add(buildMyRentalsPage(),  PAGE_RENTALS);
        contentArea.add(buildMyPaymentsPage(), PAGE_PAYMENTS);
        contentArea.add(buildProfilePage(),    PAGE_PROFILE);

        JPanel rightSide = new JPanel(new BorderLayout());
        rightSide.setBackground(AppTheme.CONTENT_BG);
        rightSide.add(topBar, BorderLayout.NORTH);
        rightSide.add(contentArea, BorderLayout.CENTER);

        root.add(sidebar,    BorderLayout.WEST);
        root.add(rightSide,  BorderLayout.CENTER);
        setContentPane(root);
    }

    private void showPage(String page, String title) {
        cardLayout.show(contentArea, page);
        topBar.setBreadcrumb(title);
    }

    // ── HOME PAGE ───────────────────────────────────────────────────────────────
    private JPanel buildHomePage() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(AppTheme.CONTENT_BG);

        JPanel page = new JPanel();
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBackground(AppTheme.CONTENT_BG);
        page.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        // Welcome banner
        JPanel banner = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, new Color(37, 99, 235),
                    getWidth(), getHeight(), new Color(79, 70, 229));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        banner.setOpaque(false);
        banner.setLayout(new BorderLayout());
        banner.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));
        banner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));

        JPanel bannerText = new JPanel();
        bannerText.setLayout(new BoxLayout(bannerText, BoxLayout.Y_AXIS));
        bannerText.setOpaque(false);

        JLabel greet = new JLabel("Welcome back, " + currentUser.getFullName() + " 👋");
        greet.setFont(new Font("Segoe UI", Font.BOLD, 22));
        greet.setForeground(Color.WHITE);

        JLabel greetSub = new JLabel("Ready to rent your next vehicle? Browse our available fleet.");
        greetSub.setFont(AppTheme.FONT_BODY);
        greetSub.setForeground(new Color(219, 234, 254));

        bannerText.add(greet);
        bannerText.add(Box.createVerticalStrut(6));
        bannerText.add(greetSub);

        JButton browseBtn = new JButton("Browse Fleet  →") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        browseBtn.setFont(AppTheme.FONT_BODY_BOLD);
        browseBtn.setForeground(AppTheme.PRIMARY);
        browseBtn.setContentAreaFilled(false);
        browseBtn.setBorderPainted(false);
        browseBtn.setFocusPainted(false);
        browseBtn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        browseBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        browseBtn.addActionListener(e -> showPage(PAGE_VEHICLES, "Browse Vehicles"));

        banner.add(bannerText, BorderLayout.CENTER);
        banner.add(browseBtn,  BorderLayout.EAST);
        page.add(banner);
        page.add(Box.createVerticalStrut(20));

        // KPI row
        KpiCard kpiActive  = new KpiCard("📋", "Active Rentals",    "—", "Loading...", AppTheme.PRIMARY);
        KpiCard kpiSpend   = new KpiCard("💰", "Total Spent",       "—", "All time",   AppTheme.SUCCESS);
        KpiCard kpiVehicles= new KpiCard("🚗", "Available Vehicles","—", "Right now",  AppTheme.INFO);
        KpiCard kpiPending = new KpiCard("⏳", "Pending Payments",  "—", "Due",        AppTheme.WARNING);

        JPanel kpiRow = KpiCard.buildKpiRow(kpiActive, kpiSpend, kpiVehicles, kpiPending);
        kpiRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        page.add(kpiRow);
        page.add(Box.createVerticalStrut(20));

        // Load KPIs
        SwingWorker<Void, Void> kpiW = new SwingWorker<Void, Void>() {
            int activeRentals = 0, availVehicles = 0, pendingPay = 0;
            double totalSpent = 0;
            @Override
            protected Void doInBackground() throws Exception {
                try {
                    Registry r = ClientRegistry.getRegistry();
                    RentalService rs = (RentalService) r.lookup("rental");
                    PaymentService ps = (PaymentService) r.lookup("payment");
                    VehicleService vs = (VehicleService) r.lookup("vehicle");
                    for (Rental rental : rs.displayAllRentals()) {
                        if (rental.getCustomer() != null &&
                            rental.getCustomer().getUserId() == currentUser.getUserId()) {
                            if ("ONGOING".equalsIgnoreCase(rental.getRentalStatus())) activeRentals++;
                        }
                    }
                    for (Payment p : ps.displayAllPayments()) {
                        if (p.getRental() != null && p.getRental().getCustomer() != null &&
                            p.getRental().getCustomer().getUserId() == currentUser.getUserId()) {
                            totalSpent += p.getAmountPaid();
                            if ("PENDING".equalsIgnoreCase(p.getPaymentStatus())) pendingPay++;
                        }
                    }
                    for (Vehicle v : vs.displayAllVehicles())
                        if ("AVAILABLE".equalsIgnoreCase(v.getAvailabilityStatus())) availVehicles++;
                } catch (Exception ignored) {}
                return null;
            }
            @Override
            protected void done() {
                kpiActive.setValue(String.valueOf(activeRentals));
                kpiActive.setTrend(activeRentals > 0 ? "▲ Active" : "None active");
                kpiSpend.setValue(String.format("$%,.2f", totalSpent));
                kpiSpend.setTrend("Lifetime");
                kpiVehicles.setValue(String.valueOf(availVehicles));
                kpiVehicles.setTrend("Ready to rent");
                kpiPending.setValue(String.valueOf(pendingPay));
                kpiPending.setTrend(pendingPay > 0 ? "Action needed" : "All clear ✓");
            }
        };
        kpiW.execute();

        // Quick actions
        JPanel actCard = AppTheme.createCard();
        actCard.setLayout(new BorderLayout());
        actCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        actCard.add(AppTheme.createSectionTitle("Quick Actions"), BorderLayout.NORTH);
        JPanel acts = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        acts.setBackground(AppTheme.CARD_BG);
        JButton b1 = AppTheme.createPrimaryButton("🚗  Rent a Vehicle");
        b1.addActionListener(e -> showPage(PAGE_VEHICLES, "Browse Vehicles"));
        JButton b2 = AppTheme.createSecondaryButton("📋  My Rentals");
        b2.addActionListener(e -> showPage(PAGE_RENTALS, "My Rentals"));
        JButton b3 = AppTheme.createSuccessButton("💳  Payment History");
        b3.addActionListener(e -> showPage(PAGE_PAYMENTS, "Payment History"));
        JButton b4 = AppTheme.createSecondaryButton("👤  My Profile");
        b4.addActionListener(e -> showPage(PAGE_PROFILE, "My Profile"));
        acts.add(b1); acts.add(b2); acts.add(b3); acts.add(b4);
        actCard.add(acts, BorderLayout.CENTER);
        page.add(actCard);
        page.add(Box.createVerticalStrut(20));

        // Recent activity
        page.add(buildActivityCard());
        page.add(Box.createVerticalStrut(24));

        outer.add(AppTheme.createScrollPane(page), BorderLayout.CENTER);
        return outer;
    }

    private JPanel buildActivityCard() {
        JPanel card = AppTheme.createCard();
        card.setLayout(new BorderLayout());
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 200));

        JLabel title = AppTheme.createSectionTitle("Recent Activity");
        card.add(title, BorderLayout.NORTH);

        JPanel list = new JPanel();
        list.setLayout(new BoxLayout(list, BoxLayout.Y_AXIS));
        list.setBackground(AppTheme.CARD_BG);
        list.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        String[][] items = {
            {"🔑", "Portal login",                      "Just now",  AppTheme.PRIMARY.toString()},
            {"✅", "System connected via RMI",           "Just now",  AppTheme.SUCCESS.toString()},
            {"📋", "Account: " + currentUser.getEmail(), "Session",   AppTheme.INFO.toString()},
        };

        for (String[] item : items) {
            JPanel row = new JPanel(new BorderLayout(10, 0));
            row.setBackground(AppTheme.CARD_BG);
            row.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, AppTheme.CARD_BORDER),
                BorderFactory.createEmptyBorder(8, 4, 8, 4)
            ));
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

            JLabel icon = new JLabel(item[0]);
            icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
            JLabel text = new JLabel(item[1]);
            text.setFont(AppTheme.FONT_BODY);
            text.setForeground(AppTheme.TEXT_PRIMARY);
            JLabel time = new JLabel(item[2]);
            time.setFont(AppTheme.FONT_SMALL);
            time.setForeground(AppTheme.TEXT_MUTED);

            JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            left.setBackground(AppTheme.CARD_BG);
            left.add(icon); left.add(text);
            row.add(left, BorderLayout.CENTER);
            row.add(time, BorderLayout.EAST);
            list.add(row);
        }
        card.add(list, BorderLayout.CENTER);
        return card;
    }

    // ── MY RENTALS PAGE ─────────────────────────────────────────────────────────
    private JPanel buildMyRentalsPage() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(AppTheme.CONTENT_BG);

        JPanel page = new JPanel();
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBackground(AppTheme.CONTENT_BG);
        page.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JLabel title = new JLabel("My Rentals");
        title.setFont(AppTheme.FONT_TITLE);
        title.setForeground(AppTheme.TEXT_PRIMARY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel sub = new JLabel("All your active and past rental agreements");
        sub.setFont(AppTheme.FONT_BODY);
        sub.setForeground(AppTheme.TEXT_SECONDARY);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(title);
        page.add(Box.createVerticalStrut(2));
        page.add(sub);
        page.add(Box.createVerticalStrut(18));

        // Table card
        JPanel tableCard = AppTheme.createCard();
        tableCard.setLayout(new BorderLayout());
        tableCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 500));

        String[] cols = {"Rental ID", "Vehicle", "Start Date", "End Date", "Days", "Total ($)", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = new JTable(model);
        TableStyler.applyStyle(tbl);
        tbl.getColumnModel().getColumn(6).setCellRenderer(new TableStyler.StatusBadgeRenderer());

        JPanel toolbar = TableStyler.buildTableToolbar(tbl, model, "My Rental History", false);
        tableCard.add(toolbar, BorderLayout.NORTH);
        tableCard.add(AppTheme.createScrollPane(tbl), BorderLayout.CENTER);
        tableCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(tableCard);

        // Load data
        SwingWorker<List<Rental>, Void> w = new SwingWorker<List<Rental>, Void>() {
            @Override
            protected List<Rental> doInBackground() throws Exception {
                Registry r = ClientRegistry.getRegistry();
                RentalService rs = (RentalService) r.lookup("rental");
                return rs.displayAllRentals();
            }
            @Override
            protected void done() {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    for (Rental rental : get()) {
                        if (rental.getCustomer() != null &&
                            rental.getCustomer().getUserId() == currentUser.getUserId()) {
                            model.addRow(new Object[]{
                                rental.getRentalId(),
                                rental.getVehicle() != null ?
                                    rental.getVehicle().getBrand() + " " + rental.getVehicle().getModel() : "—",
                                rental.getStartDate() != null ? sdf.format(rental.getStartDate()) : "—",
                                rental.getEndDate()   != null ? sdf.format(rental.getEndDate()) : "—",
                                rental.getRentalDays(),
                                String.format("$%.2f", rental.getTotalAmount()),
                                rental.getRentalStatus()
                            });
                        }
                    }
                } catch (Exception ignored) {}
            }
        };
        w.execute();

        outer.add(AppTheme.createScrollPane(page), BorderLayout.CENTER);
        return outer;
    }

    // ── MY PAYMENTS PAGE ────────────────────────────────────────────────────────
    private JPanel buildMyPaymentsPage() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(AppTheme.CONTENT_BG);

        JPanel page = new JPanel();
        page.setLayout(new BoxLayout(page, BoxLayout.Y_AXIS));
        page.setBackground(AppTheme.CONTENT_BG);
        page.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JLabel title = new JLabel("Payment History");
        title.setFont(AppTheme.FONT_TITLE);
        title.setForeground(AppTheme.TEXT_PRIMARY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(title);
        page.add(Box.createVerticalStrut(18));

        // Table card
        JPanel tableCard = AppTheme.createCard();
        tableCard.setLayout(new BorderLayout());
        tableCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 500));

        String[] cols = {"Payment ID", "Rental ID", "Amount Paid", "Method", "Date", "Status"};
        DefaultTableModel model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable tbl = new JTable(model);
        TableStyler.applyStyle(tbl);
        tbl.getColumnModel().getColumn(5).setCellRenderer(new TableStyler.StatusBadgeRenderer());

        tableCard.add(TableStyler.buildTableToolbar(tbl, model, "Payment Records", false), BorderLayout.NORTH);
        tableCard.add(AppTheme.createScrollPane(tbl), BorderLayout.CENTER);
        tableCard.setAlignmentX(Component.LEFT_ALIGNMENT);
        page.add(tableCard);

        SwingWorker<List<Payment>, Void> w = new SwingWorker<List<Payment>, Void>() {
            @Override
            protected List<Payment> doInBackground() throws Exception {
                Registry r = ClientRegistry.getRegistry();
                PaymentService ps = (PaymentService) r.lookup("payment");
                return ps.displayAllPayments();
            }
            @Override
            protected void done() {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                    for (Payment p : get()) {
                        if (p.getRental() != null && p.getRental().getCustomer() != null &&
                            p.getRental().getCustomer().getUserId() == currentUser.getUserId()) {
                            model.addRow(new Object[]{
                                p.getPaymentId(),
                                p.getRental().getRentalId(),
                                String.format("$%.2f", p.getAmountPaid()),
                                p.getPaymentMethod(),
                                p.getPaymentDate() != null ? sdf.format(p.getPaymentDate()) : "—",
                                p.getPaymentStatus()
                            });
                        }
                    }
                } catch (Exception ignored) {}
            }
        };
        w.execute();

        outer.add(AppTheme.createScrollPane(page), BorderLayout.CENTER);
        return outer;
    }

    // ── PROFILE PAGE ─────────────────────────────────────────────────────────────
    private JPanel buildProfilePage() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(AppTheme.CONTENT_BG);

        JPanel page = new JPanel(new GridBagLayout());
        page.setBackground(AppTheme.CONTENT_BG);

        JPanel profileCard = AppTheme.createCard();
        profileCard.setPreferredSize(new Dimension(480, 420));
        profileCard.setLayout(new BoxLayout(profileCard, BoxLayout.Y_AXIS));

        // Avatar circle
        JPanel avatarCircle = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(AppTheme.PRIMARY_LIGHT);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        avatarCircle.setOpaque(false);
        avatarCircle.setPreferredSize(new Dimension(80, 80));
        avatarCircle.setMaximumSize(new Dimension(80, 80));
        avatarCircle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel avatarIcon = new JLabel("👤", JLabel.CENTER);
        avatarIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        avatarCircle.add(avatarIcon);

        JLabel nameLabel = new JLabel(currentUser.getFullName(), JLabel.CENTER);
        nameLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        nameLabel.setForeground(AppTheme.TEXT_PRIMARY);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel roleLabel = AppTheme.createStatusBadge(currentUser.getRole());
        roleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        profileCard.add(Box.createVerticalStrut(10));
        profileCard.add(avatarCircle);
        profileCard.add(Box.createVerticalStrut(12));
        profileCard.add(nameLabel);
        profileCard.add(Box.createVerticalStrut(6));
        profileCard.add(roleLabel);
        profileCard.add(Box.createVerticalStrut(20));
        profileCard.add(profileSep());

        // Info rows
        profileCard.add(profileInfoRow("📧  Email",  currentUser.getEmail()));
        profileCard.add(profileSep());
        profileCard.add(profileInfoRow("📱  Phone",  currentUser.getPhoneNumber()));
        profileCard.add(profileSep());
        profileCard.add(profileInfoRow("🔐  Role",   currentUser.getRole()));
        profileCard.add(profileSep());
        profileCard.add(profileInfoRow("✅  Status", currentUser.getStatus()));
        profileCard.add(Box.createVerticalStrut(20));

        JButton editBtn = AppTheme.createPrimaryButton("✏  Edit Profile");
        editBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
        editBtn.addActionListener(e -> JOptionPane.showMessageDialog(this,
            "Profile editing — connect to UserService.updateUser()", "Edit Profile", JOptionPane.INFORMATION_MESSAGE));
        profileCard.add(editBtn);

        page.add(profileCard);
        outer.add(page, BorderLayout.CENTER);
        return outer;
    }

    private JPanel profileInfoRow(String label, String value) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(AppTheme.CARD_BG);
        row.setBorder(BorderFactory.createEmptyBorder(10, 4, 10, 4));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        JLabel lbl = new JLabel(label);
        lbl.setFont(AppTheme.FONT_BODY);
        lbl.setForeground(AppTheme.TEXT_SECONDARY);

        JLabel val = new JLabel(value == null ? "—" : value);
        val.setFont(AppTheme.FONT_BODY_BOLD);
        val.setForeground(AppTheme.TEXT_PRIMARY);

        row.add(lbl, BorderLayout.WEST);
        row.add(val, BorderLayout.EAST);
        return row;
    }

    private JPanel profileSep() {
        JPanel sep = new JPanel();
        sep.setBackground(AppTheme.CARD_BORDER);
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setPreferredSize(new Dimension(0, 1));
        return sep;
    }

    private void doLogout() {
        int c = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?", "Confirm Logout",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (c == JOptionPane.YES_OPTION) {
            new LoginFrame().setVisible(true);
            dispose();
        }
    }
}

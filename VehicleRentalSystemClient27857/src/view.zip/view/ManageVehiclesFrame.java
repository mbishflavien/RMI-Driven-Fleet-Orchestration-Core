package view;

import view.util.*;
import controller.ClientRegistry;
import model.Vehicle;
import service.VehicleService;

import java.awt.*;
import java.awt.event.*;
import java.rmi.registry.Registry;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

/**
 * ManageVehiclesFrame - Premium vehicle management panel.
 * Used as embedded panel inside AdminDashboardFrame.
 */
public class ManageVehiclesFrame extends javax.swing.JFrame {

    public ManageVehiclesFrame() {
        AppTheme.applyGlobalDefaults();
        setTitle("Vehicle Rental System — Manage Vehicles");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.CONTENT_BG);
        root.add(new VehiclesPanel(), BorderLayout.CENTER);
        setContentPane(root);
    }

    // ── INNER STATIC PANEL (embeddable into dashboard) ─────────────────────────
    public static class VehiclesPanel extends JPanel {

        private JTable table;
        private DefaultTableModel tableModel;
        private JTextField txtId, txtPlate, txtBrand, txtModel, txtCategory, txtRate, txtYear;
        private JComboBox<String> cmbAvailability, cmbCondition;
        private JLabel lblMsg;

        public VehiclesPanel() {
            setLayout(new BorderLayout());
            setBackground(AppTheme.CONTENT_BG);
            buildUI();
            loadVehicles();
        }

        private void buildUI() {
            JPanel mainContent = new JPanel(new BorderLayout(14, 0));
            mainContent.setBackground(AppTheme.CONTENT_BG);
            mainContent.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            // ── PAGE HEADER ─────────────────────────────────────────────────────
            JPanel pageHeader = new JPanel(new BorderLayout());
            pageHeader.setBackground(AppTheme.CONTENT_BG);
            pageHeader.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));

            JLabel pageTitle = new JLabel("Vehicle Management");
            pageTitle.setFont(AppTheme.FONT_TITLE);
            pageTitle.setForeground(AppTheme.TEXT_PRIMARY);

            JLabel pageSub = new JLabel("Add, edit and manage your vehicle fleet");
            pageSub.setFont(AppTheme.FONT_BODY);
            pageSub.setForeground(AppTheme.TEXT_SECONDARY);

            JPanel titleStack = new JPanel();
            titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
            titleStack.setBackground(AppTheme.CONTENT_BG);
            titleStack.add(pageTitle);
            titleStack.add(pageSub);
            pageHeader.add(titleStack, BorderLayout.WEST);

            // ── LEFT: FORM CARD ────────────────────────────────────────────────
            JPanel formCard = AppTheme.createCard();
            formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
            formCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));

            addFormTitle(formCard, "Vehicle Details");

            txtId       = hiddenField(formCard, "ID (auto)");
            txtPlate    = formField(formCard, "Plate Number",   "e.g. ABC-1234");
            txtBrand    = formField(formCard, "Brand",          "e.g. Toyota");
            txtModel    = formField(formCard, "Model",          "e.g. Camry");
            txtCategory = formField(formCard, "Category",       "Sedan / SUV / Truck");
            txtRate     = formField(formCard, "Daily Rate ($)", "e.g. 75.00");
            txtYear     = formField(formCard, "Manufacture Year","e.g. 2022");

            JLabel availLbl = lbl("Availability");
            availLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            cmbAvailability = AppTheme.createComboBox(new String[]{"AVAILABLE", "RENTED", "MAINTENANCE"});
            cmbAvailability.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            cmbAvailability.setAlignmentX(Component.LEFT_ALIGNMENT);
            formCard.add(availLbl);
            formCard.add(Box.createVerticalStrut(4));
            formCard.add(cmbAvailability);
            formCard.add(Box.createVerticalStrut(10));

            JLabel condLbl = lbl("Condition");
            condLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            cmbCondition = AppTheme.createComboBox(new String[]{"EXCELLENT", "GOOD", "FAIR", "POOR"});
            cmbCondition.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            cmbCondition.setAlignmentX(Component.LEFT_ALIGNMENT);
            formCard.add(condLbl);
            formCard.add(Box.createVerticalStrut(4));
            formCard.add(cmbCondition);
            formCard.add(Box.createVerticalStrut(16));

            // Message label
            lblMsg = new JLabel(" ");
            lblMsg.setFont(AppTheme.FONT_SMALL);
            lblMsg.setForeground(AppTheme.SUCCESS);
            lblMsg.setAlignmentX(Component.LEFT_ALIGNMENT);
            formCard.add(lblMsg);
            formCard.add(Box.createVerticalStrut(8));

            // Buttons
            JButton btnAdd = AppTheme.createPrimaryButton("Add Vehicle");
            btnAdd.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            btnAdd.setAlignmentX(Component.LEFT_ALIGNMENT);
            btnAdd.addActionListener(e -> addVehicle());

            JButton btnUpdate = AppTheme.createWarningButton("Update");
            btnUpdate.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            btnUpdate.setAlignmentX(Component.LEFT_ALIGNMENT);
            btnUpdate.addActionListener(e -> updateVehicle());

            JButton btnDelete = AppTheme.createDangerButton("Delete");
            btnDelete.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            btnDelete.setAlignmentX(Component.LEFT_ALIGNMENT);
            btnDelete.addActionListener(e -> deleteVehicle());

            JButton btnClear = AppTheme.createSecondaryButton("Clear Form");
            btnClear.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
            btnClear.setAlignmentX(Component.LEFT_ALIGNMENT);
            btnClear.addActionListener(e -> clearForm());

            formCard.add(btnAdd);
            formCard.add(Box.createVerticalStrut(6));
            formCard.add(btnUpdate);
            formCard.add(Box.createVerticalStrut(6));
            formCard.add(btnDelete);
            formCard.add(Box.createVerticalStrut(10));
            formCard.add(btnClear);
            formCard.add(Box.createVerticalStrut(10));

            // ── RIGHT: TABLE CARD ──────────────────────────────────────────────
            JPanel tableCard = AppTheme.createCard();
            tableCard.setLayout(new BorderLayout());

            String[] cols = {"ID", "Plate", "Brand", "Model", "Category",
                             "Daily Rate", "Year", "Availability", "Condition"};
            tableModel = new DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };

            table = new JTable(tableModel);
            TableStyler.applyStyle(table);
            // Status column badge renderer
            table.getColumnModel().getColumn(7).setCellRenderer(new TableStyler.StatusBadgeRenderer());
            // Column widths
            int[] widths = {40, 90, 80, 80, 80, 80, 55, 100, 80};
            for (int i = 0; i < widths.length; i++)
                table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);

            // Row click → populate form
            table.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) populateFormFromTable();
            });

            JPanel toolbar = TableStyler.buildTableToolbar(table, tableModel, "Fleet Registry", true);

            JScrollPane tableScroll = AppTheme.createScrollPane(table);
            tableCard.add(toolbar, BorderLayout.NORTH);
            tableCard.add(tableScroll, BorderLayout.CENTER);

            mainContent.add(pageHeader, BorderLayout.NORTH);
            JPanel leftWrapper = new JPanel(new BorderLayout());
            leftWrapper.setBackground(AppTheme.CONTENT_BG);
            leftWrapper.setPreferredSize(new Dimension(340, 0));

            JScrollPane formScroll = new JScrollPane(formCard);
            formScroll.setBorder(null);
            formScroll.setHorizontalScrollBarPolicy(
                    JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

            formScroll.getVerticalScrollBar().setUnitIncrement(16);

            leftWrapper.add(formScroll, BorderLayout.CENTER);
            
            formCard.add(Box.createVerticalGlue());
            
            formScroll.getVerticalScrollBar().setUnitIncrement(16);

            mainContent.add(leftWrapper, BorderLayout.WEST);
            mainContent.add(tableCard, BorderLayout.CENTER);
            
            add(mainContent, BorderLayout.CENTER);
        }

        private void loadVehicles() {
            SwingWorker<List<Vehicle>, Void> w = new SwingWorker<List<Vehicle>, Void>() {
                @Override
                protected List<Vehicle> doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    VehicleService vs = (VehicleService) r.lookup("vehicle");
                    return vs.displayAllVehicles();
                }
                @Override
                protected void done() {
                    try {
                        tableModel.setRowCount(0);
                        for (Vehicle v : get()) {
                            tableModel.addRow(new Object[]{
                                v.getVehicleId(), v.getPlateNumber(), v.getBrand(),
                                v.getModel(), v.getCategory(),
                                String.format("$%.2f", v.getDailyRate()),
                                v.getManufactureYear(),
                                v.getAvailabilityStatus(), v.getConditionStatus()
                            });
                        }
                        msg("Loaded " + tableModel.getRowCount() + " vehicles.", false);
                    } catch (Exception ex) {
                        msg("Load error: " + ex.getMessage(), true);
                    }
                }
            };
            w.execute();
        }

        private void addVehicle() {
            if (!validateForm()) return;
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    VehicleService vs = (VehicleService) r.lookup("vehicle");
                    Vehicle v = buildVehicleFromForm(0);
                    return vs.registerVehicle(v);
                }
                @Override
                protected void done() {
                    try {
                        get();
                        msg("Vehicle added successfully!", false);
                        clearForm();
                        loadVehicles();
                    } catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void updateVehicle() {
            if (txtId.getText().trim().isEmpty() || txtId.getText().trim().equals("0")) {
                msg("Select a vehicle to update.", true); return;
            }
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    VehicleService vs = (VehicleService) r.lookup("vehicle");
                    Vehicle v = buildVehicleFromForm(Integer.parseInt(txtId.getText().trim()));
                    return vs.updateVehicle(v);
                }
                @Override
                protected void done() {
                    try {
                        get();
                        msg("Vehicle updated successfully!", false);
                        loadVehicles();
                    } catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void deleteVehicle() {
            if (txtId.getText().trim().isEmpty() || txtId.getText().trim().equals("0")) {
                msg("Select a vehicle to delete.", true); return;
            }
            int confirm = JOptionPane.showConfirmDialog(this,
                "Delete vehicle " + txtPlate.getText() + "?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) return;

            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    VehicleService vs = (VehicleService) r.lookup("vehicle");
                    Vehicle v = new Vehicle();
                    v.setVehicleId(Integer.parseInt(txtId.getText().trim()));
                    return vs.deleteVehicle(v);
                }
                @Override
                protected void done() {
                    try {
                        get();
                        msg("Vehicle deleted.", false);
                        clearForm();
                        loadVehicles();
                    } catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void populateFormFromTable() {
            int row = table.getSelectedRow();
            if (row < 0) return;
            int modelRow = table.convertRowIndexToModel(row);
            txtId.setText(tableModel.getValueAt(modelRow, 0).toString());
            txtPlate.setText(tableModel.getValueAt(modelRow, 1).toString());
            txtBrand.setText(tableModel.getValueAt(modelRow, 2).toString());
            txtModel.setText(tableModel.getValueAt(modelRow, 3).toString());
            txtCategory.setText(tableModel.getValueAt(modelRow, 4).toString());
            txtRate.setText(tableModel.getValueAt(modelRow, 5).toString().replace("$", ""));
            txtYear.setText(tableModel.getValueAt(modelRow, 6).toString());
            String avail = tableModel.getValueAt(modelRow, 7).toString();
            String cond  = tableModel.getValueAt(modelRow, 8).toString();
            for (int i = 0; i < cmbAvailability.getItemCount(); i++)
                if (cmbAvailability.getItemAt(i).equalsIgnoreCase(avail)) { cmbAvailability.setSelectedIndex(i); break; }
            for (int i = 0; i < cmbCondition.getItemCount(); i++)
                if (cmbCondition.getItemAt(i).equalsIgnoreCase(cond)) { cmbCondition.setSelectedIndex(i); break; }
        }

        private Vehicle buildVehicleFromForm(int id) {
            double rate = 0;
            int year = 0;
            try { rate = Double.parseDouble(txtRate.getText().trim()); } catch (Exception ignored) {}
            try { year = Integer.parseInt(txtYear.getText().trim()); } catch (Exception ignored) {}
            return new Vehicle(id, txtPlate.getText().trim(), txtBrand.getText().trim(),
                txtModel.getText().trim(), txtCategory.getText().trim(), rate,
                (String) cmbAvailability.getSelectedItem(),
                (String) cmbCondition.getSelectedItem(), year);
        }

        private boolean validateForm() {
            if (txtPlate.getText().trim().isEmpty() || txtBrand.getText().trim().isEmpty()) {
                msg("Plate and Brand are required.", true);
                return false;
            }
            return true;
        }

        private void clearForm() {
            txtId.setText(""); txtPlate.setText(""); txtBrand.setText(""); txtModel.setText("");
            txtCategory.setText(""); txtRate.setText(""); txtYear.setText("");
            cmbAvailability.setSelectedIndex(0); cmbCondition.setSelectedIndex(0);
            table.clearSelection(); lblMsg.setText(" ");
        }

        private void msg(String text, boolean error) {
            lblMsg.setText(text);
            lblMsg.setForeground(error ? AppTheme.DANGER : AppTheme.SUCCESS);
        }

        // ── Form builder helpers ────────────────────────────────────────────
        private void addFormTitle(JPanel parent, String title) {
            JLabel lbl = AppTheme.createSectionTitle(title);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            lbl.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
            parent.add(lbl);
        }

        private JTextField formField(JPanel parent, String labelText, String placeholder) {
            JLabel lbl = lbl(labelText);
            lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            JTextField tf = AppTheme.createTextField(placeholder);
            tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            tf.setAlignmentX(Component.LEFT_ALIGNMENT);
            parent.add(lbl);
            parent.add(Box.createVerticalStrut(4));
            parent.add(tf);
            parent.add(Box.createVerticalStrut(10));
            return tf;
        }

        private JTextField hiddenField(JPanel parent, String placeholder) {
            JTextField tf = AppTheme.createTextField(placeholder);
            tf.setVisible(false);
            tf.setMaximumSize(new Dimension(0, 0));
            parent.add(tf);
            return tf;
        }

        private JLabel lbl(String text) {
            JLabel l = new JLabel(text);
            l.setFont(AppTheme.FONT_BODY_BOLD);
            l.setForeground(AppTheme.TEXT_PRIMARY);
            return l;
        }
    }
}

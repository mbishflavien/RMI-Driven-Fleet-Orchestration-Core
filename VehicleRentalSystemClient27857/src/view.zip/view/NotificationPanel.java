package view;

import view.util.*;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import javax.swing.*;

/**
 * NotificationPanel - Modern notification/activity feed panel.
 * Can be embedded in any dashboard or shown as a floating panel.
 * Supports RENTAL, PAYMENT, VEHICLE, SYSTEM notification types.
 */
public class NotificationPanel extends JPanel {

    public enum NotifType { RENTAL, PAYMENT, VEHICLE, SYSTEM, ALERT }

    private JPanel feedPanel;
    private JLabel countBadge;
    private final List<NotifEntry> notifications = new ArrayList<>();
    private int unreadCount = 0;

    public NotificationPanel() {
        setLayout(new BorderLayout());
        setBackground(AppTheme.CONTENT_BG);
        buildUI();
        loadSampleNotifications();
    }

    private void buildUI() {
        // ── HEADER BAR ──────────────────────────────────────────────────────────
        JPanel headerBar = new JPanel(new BorderLayout());
        headerBar.setBackground(AppTheme.CARD_BG);
        headerBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, AppTheme.CARD_BORDER),
            BorderFactory.createEmptyBorder(14, 18, 14, 18)
        ));

        JPanel titleRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        titleRow.setBackground(AppTheme.CARD_BG);

        JLabel icon = new JLabel("🔔");
        icon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));

        JLabel title = new JLabel("Notifications");
        title.setFont(AppTheme.FONT_SUBTITLE);
        title.setForeground(AppTheme.TEXT_PRIMARY);

        countBadge = new JLabel("0") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(AppTheme.DANGER);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        countBadge.setFont(new Font("Segoe UI", Font.BOLD, 10));
        countBadge.setForeground(Color.WHITE);
        countBadge.setOpaque(false);
        countBadge.setHorizontalAlignment(JLabel.CENTER);
        countBadge.setPreferredSize(new Dimension(20, 20));

        titleRow.add(icon);
        titleRow.add(title);
        titleRow.add(countBadge);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setBackground(AppTheme.CARD_BG);

        JButton markAllRead = AppTheme.createSecondaryButton("Mark all read");
        markAllRead.addActionListener(e -> markAllAsRead());

        JButton clearAll = AppTheme.createSecondaryButton("Clear all");
        clearAll.addActionListener(e -> clearAllNotifications());

        actions.add(markAllRead);
        actions.add(clearAll);

        headerBar.add(titleRow, BorderLayout.WEST);
        headerBar.add(actions, BorderLayout.EAST);

        // ── FILTER CHIPS ────────────────────────────────────────────────────────
        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        filterRow.setBackground(new Color(248, 250, 252));
        filterRow.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, AppTheme.CARD_BORDER));

        filterRow.add(buildFilterChip("All",     true));
        filterRow.add(buildFilterChip("Rentals", false));
        filterRow.add(buildFilterChip("Payments",false));
        filterRow.add(buildFilterChip("Alerts",  false));
        filterRow.add(buildFilterChip("System",  false));

        // ── FEED PANEL ──────────────────────────────────────────────────────────
        feedPanel = new JPanel();
        feedPanel.setLayout(new BoxLayout(feedPanel, BoxLayout.Y_AXIS));
        feedPanel.setBackground(AppTheme.CONTENT_BG);
        feedPanel.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));

        JScrollPane scroll = AppTheme.createScrollPane(feedPanel);
        scroll.getViewport().setBackground(AppTheme.CONTENT_BG);

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(AppTheme.CONTENT_BG);
        top.add(headerBar,  BorderLayout.NORTH);
        top.add(filterRow,  BorderLayout.SOUTH);

        add(top,    BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
    }

    // ── NOTIFICATION ENTRY ───────────────────────────────────────────────────────
    private JPanel buildNotifItem(NotifEntry entry) {
        JPanel item = new JPanel(new BorderLayout(12, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(entry.read ? AppTheme.CONTENT_BG : new Color(239, 246, 255));
                g2.fillRect(0, 0, getWidth(), getHeight());
                // Unread indicator bar
                if (!entry.read) {
                    g2.setColor(AppTheme.PRIMARY);
                    g2.fillRect(0, 0, 3, getHeight());
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        item.setOpaque(false);
        item.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, AppTheme.CARD_BORDER),
            BorderFactory.createEmptyBorder(12, 18, 12, 16)
        ));
        item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 72));
        item.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        // Hover effect
        item.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { item.setBackground(new Color(248,250,252)); item.repaint(); }
            @Override public void mouseExited(MouseEvent e)  { item.repaint(); }
            @Override
            public void mouseClicked(MouseEvent e) {
                entry.read = true;
                if (unreadCount > 0) { unreadCount--; updateBadge(); }
                item.repaint();
            }
        });

        // Icon circle
        JPanel iconCircle = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = typeColor(entry.type);
                g2.setColor(new Color(bg.getRed(), bg.getGreen(), bg.getBlue(), 25));
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        iconCircle.setOpaque(false);
        iconCircle.setPreferredSize(new Dimension(40, 40));
        iconCircle.setMinimumSize(new Dimension(40, 40));
        iconCircle.setMaximumSize(new Dimension(40, 40));

        JLabel iconLbl = new JLabel(typeIcon(entry.type), JLabel.CENTER);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
        iconCircle.add(iconLbl);

        // Text content
        JPanel textCol = new JPanel();
        textCol.setLayout(new BoxLayout(textCol, BoxLayout.Y_AXIS));
        textCol.setOpaque(false);

        JLabel titleLbl = new JLabel(entry.title);
        titleLbl.setFont(entry.read ? AppTheme.FONT_BODY : AppTheme.FONT_BODY_BOLD);
        titleLbl.setForeground(AppTheme.TEXT_PRIMARY);

        JLabel msgLbl = new JLabel(entry.message);
        msgLbl.setFont(AppTheme.FONT_SMALL);
        msgLbl.setForeground(AppTheme.TEXT_SECONDARY);

        textCol.add(titleLbl);
        textCol.add(Box.createVerticalStrut(3));
        textCol.add(msgLbl);

        // Time + dismiss
        JPanel rightCol = new JPanel();
        rightCol.setLayout(new BoxLayout(rightCol, BoxLayout.Y_AXIS));
        rightCol.setOpaque(false);

        JLabel timeLbl = new JLabel(entry.timeAgo);
        timeLbl.setFont(AppTheme.FONT_SMALL);
        timeLbl.setForeground(AppTheme.TEXT_MUTED);
        timeLbl.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel typeLbl = AppTheme.createStatusBadge(entry.type.name());
        typeLbl.setAlignmentX(Component.RIGHT_ALIGNMENT);

        rightCol.add(timeLbl);
        rightCol.add(Box.createVerticalStrut(4));
        rightCol.add(typeLbl);

        item.add(iconCircle, BorderLayout.WEST);
        item.add(textCol,    BorderLayout.CENTER);
        item.add(rightCol,   BorderLayout.EAST);

        return item;
    }

    // ── PUBLIC API ───────────────────────────────────────────────────────────────

    /** Add a new notification to the feed */
    public void addNotification(String title, String message, NotifType type) {
        NotifEntry entry = new NotifEntry(title, message, type, false, "Just now");
        notifications.add(0, entry);
        unreadCount++;
        refreshFeed();
        updateBadge();
    }

    /** Add a late return alert */
    public void addLateReturnAlert(int rentalId, String customerName) {
        addNotification("⚠️ Late Return",
            "Rental #" + rentalId + " — " + customerName + " has not returned the vehicle.",
            NotifType.ALERT);
    }

    /** Add a payment confirmation */
    public void addPaymentConfirmation(int paymentId, String amount) {
        addNotification("✅ Payment Received",
            "Payment #" + paymentId + " of " + amount + " confirmed.",
            NotifType.PAYMENT);
    }

    // ── PRIVATE HELPERS ──────────────────────────────────────────────────────────

    private void loadSampleNotifications() {
        notifications.add(new NotifEntry("New Rental Created",
            "Customer John Doe rented Toyota Camry for 5 days.", NotifType.RENTAL, false, "2 min ago"));
        notifications.add(new NotifEntry("Payment Received",
            "Payment of $375.00 received for Rental #42.", NotifType.PAYMENT, false, "15 min ago"));
        notifications.add(new NotifEntry("⚠️ Late Return Alert",
            "Vehicle ABC-1234 is 2 days overdue. Contact customer.", NotifType.ALERT, false, "1 hr ago"));
        notifications.add(new NotifEntry("Vehicle Maintenance Due",
            "Honda CR-V (DEF-5678) is scheduled for maintenance.", NotifType.VEHICLE, true, "3 hrs ago"));
        notifications.add(new NotifEntry("System Startup",
            "VRS Server connected successfully via RMI.", NotifType.SYSTEM, true, "Today"));
        notifications.add(new NotifEntry("New Customer Registered",
            "Jane Smith created a new customer account.", NotifType.SYSTEM, true, "Yesterday"));

        unreadCount = (int) notifications.stream().filter(n -> !n.read).count();
        refreshFeed();
        updateBadge();
    }

    private void refreshFeed() {
        feedPanel.removeAll();
        if (notifications.isEmpty()) {
            JPanel empty = new JPanel(new GridBagLayout());
            empty.setBackground(AppTheme.CONTENT_BG);
            empty.setPreferredSize(new Dimension(0, 200));
            JPanel inner = new JPanel(); inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS)); inner.setBackground(AppTheme.CONTENT_BG);
            JLabel emoji = new JLabel("🔕", JLabel.CENTER); emoji.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 40)); emoji.setAlignmentX(Component.CENTER_ALIGNMENT);
            JLabel msg = new JLabel("No notifications", JLabel.CENTER); msg.setFont(AppTheme.FONT_BODY); msg.setForeground(AppTheme.TEXT_MUTED); msg.setAlignmentX(Component.CENTER_ALIGNMENT);
            inner.add(emoji); inner.add(Box.createVerticalStrut(10)); inner.add(msg);
            empty.add(inner);
            feedPanel.add(empty);
        } else {
            for (NotifEntry entry : notifications) {
                feedPanel.add(buildNotifItem(entry));
            }
        }
        feedPanel.revalidate();
        feedPanel.repaint();
    }

    private void markAllAsRead() {
        notifications.forEach(n -> n.read = true);
        unreadCount = 0;
        updateBadge();
        refreshFeed();
    }

    private void clearAllNotifications() {
        notifications.clear();
        unreadCount = 0;
        updateBadge();
        refreshFeed();
    }

    private void updateBadge() {
        countBadge.setText(String.valueOf(unreadCount));
        countBadge.setVisible(unreadCount > 0);
    }

    private JLabel buildFilterChip(String text, boolean active) {
        JLabel chip = new JLabel(text, JLabel.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(active ? AppTheme.PRIMARY : new Color(226, 232, 240));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        chip.setFont(new Font("Segoe UI", Font.BOLD, 11));
        chip.setForeground(active ? Color.WHITE : AppTheme.TEXT_SECONDARY);
        chip.setOpaque(false);
        chip.setBorder(BorderFactory.createEmptyBorder(5, 12, 5, 12));
        chip.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return chip;
    }

    private Color typeColor(NotifType type) {
        switch (type) {
            case RENTAL:  return AppTheme.PRIMARY;
            case PAYMENT: return AppTheme.SUCCESS;
            case VEHICLE: return AppTheme.INFO;
            case ALERT:   return AppTheme.DANGER;
            default:      return AppTheme.TEXT_MUTED;
        }
    }

    private String typeIcon(NotifType type) {
        switch (type) {
            case RENTAL:  return "📋";
            case PAYMENT: return "💳";
            case VEHICLE: return "🚗";
            case ALERT:   return "⚠️";
            default:      return "⚙️";
        }
    }

    // ── DATA MODEL ───────────────────────────────────────────────────────────────
    public static class NotifEntry {
        public String   title, message, timeAgo;
        public NotifType type;
        public boolean   read;

        public NotifEntry(String title, String message, NotifType type, boolean read, String timeAgo) {
            this.title = title; this.message = message;
            this.type = type; this.read = read; this.timeAgo = timeAgo;
        }
    }

    /** Convenience: show as a floating dialog */
    public static void showAsDialog(java.awt.Window parent) {
        JDialog dialog = new JDialog(parent instanceof JFrame ? (JFrame) parent : null,
            "Notifications", false);
        dialog.setSize(460, 600);
        dialog.setLocationRelativeTo(parent);
        dialog.add(new NotificationPanel());
        dialog.setVisible(true);
    }
}

package view;

import view.util.*;
import controller.ClientRegistry;
import model.*;
import service.*;

import java.awt.*;
import java.awt.event.*;
import java.rmi.registry.Registry;
import java.util.List;
import javax.swing.*;

/**
 * AdminDashboardFrame - Full enterprise admin dashboard.
 * Uses card layout for page switching; sidebar drives navigation.
 */
public class AdminDashboardFrame extends javax.swing.JFrame {

    private final model.User currentUser;
    private SidebarPanel sidebar;
    private TopBar topBar;
    private JPanel contentArea;
    private CardLayout cardLayout;

    // Page keys
    private static final String PAGE_DASHBOARD  = "dashboard";
    private static final String PAGE_VEHICLES   = "vehicles";
    private static final String PAGE_CUSTOMERS  = "customers";
    private static final String PAGE_RENTALS    = "rentals";
    private static final String PAGE_PAYMENTS   = "payments";
    private static final String PAGE_REPORTS    = "reports";

    public AdminDashboardFrame(model.User user) {
        this.currentUser = user;
        AppTheme.applyGlobalDefaults();
        setTitle("VRS — Admin Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 800);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);
        buildUI();
    }

    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.CONTENT_BG);

        // ── SIDEBAR ───────────────────────────────────────────────────────────
        sidebar = new SidebarPanel();
        sidebar.setProfileName(currentUser.getFullName());
        sidebar.setProfileRole("Administrator");

        sidebar.addSectionLabel("MAIN MENU");
        SidebarPanel.SidebarItem dashItem = sidebar.addMenuItem("📊", "Dashboard",   e -> showPage(PAGE_DASHBOARD, "Dashboard"));
        sidebar.addSectionLabel("MANAGEMENT");
        sidebar.addMenuItem("🚗", "Vehicles",    e -> showPage(PAGE_VEHICLES, "Manage Vehicles"));
        sidebar.addMenuItem("👥", "Customers",   e -> showPage(PAGE_CUSTOMERS, "Manage Customers"));
        sidebar.addMenuItem("📋", "Rentals",     e -> showPage(PAGE_RENTALS, "Manage Rentals"));
        sidebar.addMenuItem("💳", "Payments",    e -> showPage(PAGE_PAYMENTS, "Manage Payments"));
        sidebar.addSeparator();
        sidebar.addSectionLabel("ANALYTICS");
        sidebar.addMenuItem("📈", "Reports",     e -> showPage(PAGE_REPORTS, "Reports & Analytics"));
        sidebar.addSeparator();
        sidebar.addMenuItem("🔒", "Logout",      e -> doLogout());

        sidebar.setActiveItem(dashItem);

        // ── TOP BAR ───────────────────────────────────────────────────────────
        topBar = new TopBar("Dashboard");

        // ── CONTENT AREA ──────────────────────────────────────────────────────
        cardLayout = new CardLayout();
        contentArea = new JPanel(cardLayout);
        contentArea.setBackground(AppTheme.CONTENT_BG);
        contentArea.add(buildDashboardPage(), PAGE_DASHBOARD);
        contentArea.add(new ManageVehiclesFrame.VehiclesPanel(), PAGE_VEHICLES);
        contentArea.add(new ManageCustomersFrame.CustomersPanel(), PAGE_CUSTOMERS);
        contentArea.add(new ManageRentalsFrame.RentalsPanel(), PAGE_RENTALS);
        contentArea.add(new ManagePaymentsFrame.PaymentsPanel(), PAGE_PAYMENTS);
        contentArea.add(buildReportsPage(), PAGE_REPORTS);

        // ── RIGHT SIDE: top bar + content ─────────────────────────────────────
        JPanel rightSide = new JPanel(new BorderLayout());
        rightSide.setBackground(AppTheme.CONTENT_BG);
        rightSide.add(topBar, BorderLayout.NORTH);
        rightSide.add(contentArea, BorderLayout.CENTER);

        root.add(sidebar, BorderLayout.WEST);
        root.add(rightSide, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void showPage(String page, String title) {
        cardLayout.show(contentArea, page);
        topBar.setBreadcrumb(title);
    }

    // ── DASHBOARD HOME PAGE ────────────────────────────────────────────────────
    private JPanel buildDashboardPage() {
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(AppTheme.CONTENT_BG);

        JScrollPane scroll = AppTheme.createScrollPane(buildDashboardContent());
        page.add(scroll, BorderLayout.CENTER);
        return page;
    }

    private JPanel buildDashboardContent() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(AppTheme.CONTENT_BG);
        panel.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        // Page header
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(AppTheme.CONTENT_BG);
        header.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        JLabel title = new JLabel("Dashboard Overview");
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(AppTheme.TEXT_PRIMARY);
        JLabel subtitle = new JLabel("Welcome back, " + currentUser.getFullName());
        subtitle.setFont(AppTheme.FONT_BODY);
        subtitle.setForeground(AppTheme.TEXT_SECONDARY);
        JPanel titleStack = new JPanel();
        titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
        titleStack.setBackground(AppTheme.CONTENT_BG);
        titleStack.add(title);
        titleStack.add(subtitle);
        header.add(titleStack, BorderLayout.WEST);
        panel.add(header);
        panel.add(Box.createVerticalStrut(20));

        // ── KPI ROW 1 ─────────────────────────────────────────────────────────
        KpiCard kpi1 = new KpiCard("🚗", "Total Vehicles",    "—", "Loading...", AppTheme.PRIMARY);
        KpiCard kpi2 = new KpiCard("👥", "Active Customers",  "—", "Loading...", AppTheme.SUCCESS);
        KpiCard kpi3 = new KpiCard("📋", "Active Rentals",    "—", "Loading...", AppTheme.WARNING);
        KpiCard kpi4 = new KpiCard("💰", "Revenue (Total)",   "—", "Loading...", AppTheme.PURPLE);

        JPanel kpiRow = KpiCard.buildKpiRow(kpi1, kpi2, kpi3, kpi4);
        kpiRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        panel.add(kpiRow);
        panel.add(Box.createVerticalStrut(14));

        // ── KPI ROW 2 ─────────────────────────────────────────────────────────
        KpiCard kpi5 = new KpiCard("✅", "Available Vehicles","—", "Loading...", AppTheme.SUCCESS);
        KpiCard kpi6 = new KpiCard("⚠️", "Pending Returns",  "—", "Loading...", AppTheme.DANGER);
        KpiCard kpi7 = new KpiCard("💳", "Payments Today",   "—", "Loading...", AppTheme.INFO);
        KpiCard kpi8 = new KpiCard("📈", "Rentals This Month","—", "Loading...", AppTheme.WARNING);

        JPanel kpiRow2 = KpiCard.buildKpiRow(kpi5, kpi6, kpi7, kpi8);
        kpiRow2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        panel.add(kpiRow2);
        panel.add(Box.createVerticalStrut(20));

        // Load KPI data in background
        SwingWorker<int[], Void> kpiWorker = new SwingWorker<int[], Void>() {
            int totalVehicles = 0, activeCustomers = 0, activeRentals = 0, availableVehicles = 0;
            double totalRevenue = 0;
            @Override
            protected int[] doInBackground() throws Exception {
                try {
                    Registry r = ClientRegistry.getRegistry();
                    VehicleService vs = (VehicleService) r.lookup("vehicle");
                    UserService us = (UserService) r.lookup("user");
                    RentalService rs = (RentalService) r.lookup("rental");
                    PaymentService ps = (PaymentService) r.lookup("payment");
                    List<Vehicle> vehicles = vs.displayAllVehicles();
                    totalVehicles = vehicles.size();
                    for (Vehicle v : vehicles)
                        if ("AVAILABLE".equalsIgnoreCase(v.getAvailabilityStatus())) availableVehicles++;
                    List<User> users = us.displayAllUsers();
                    for (User u : users)
                        if ("ACTIVE".equalsIgnoreCase(u.getStatus()) && "CUSTOMER".equalsIgnoreCase(u.getRole())) activeCustomers++;
                    List<Rental> rentals = rs.displayAllRentals();
                    for (Rental rental : rentals)
                        if ("ONGOING".equalsIgnoreCase(rental.getRentalStatus())) activeRentals++;
                    List<Payment> payments = ps.displayAllPayments();
                    for (Payment p : payments) totalRevenue += p.getAmountPaid();
                } catch (Exception ignored) {}
                return new int[]{totalVehicles, activeCustomers, activeRentals, availableVehicles};
            }
            @Override
            protected void done() {
                try {
                    int[] r = get();
                    kpi1.setValue(String.valueOf(r[0]));
                    kpi1.setTrend("Fleet size");
                    kpi2.setValue(String.valueOf(r[1]));
                    kpi2.setTrend("Registered customers");
                    kpi3.setValue(String.valueOf(r[2]));
                    kpi3.setTrend("Currently rented");
                    kpi4.setValue(String.format("$%,.0f", totalRevenue));
                    kpi4.setTrend("All time revenue");
                    kpi5.setValue(String.valueOf(r[3]));
                    kpi5.setTrend("Ready to rent");
                    kpi6.setValue(String.valueOf(r[2]));
                    kpi6.setTrend("Awaiting return");
                } catch (Exception ignored) {}
            }
        };
        kpiWorker.execute();

        // ── QUICK ACTIONS ──────────────────────────────────────────────────────
        JPanel actionsCard = AppTheme.createCard();
        actionsCard.setLayout(new BorderLayout());
        actionsCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));

        JLabel actTitle = AppTheme.createSectionTitle("Quick Actions");
        actionsCard.add(actTitle, BorderLayout.NORTH);

        JPanel actBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 12));
        actBtns.setBackground(AppTheme.CARD_BG);

        JButton addVehicle = AppTheme.createPrimaryButton("+ Add Vehicle");
        addVehicle.addActionListener(e -> showPage(PAGE_VEHICLES, "Manage Vehicles"));
        JButton newRental = AppTheme.createSuccessButton("+ New Rental");
        newRental.addActionListener(e -> showPage(PAGE_RENTALS, "Manage Rentals"));
        JButton addCustomer = AppTheme.createSecondaryButton("+ Add Customer");
        addCustomer.addActionListener(e -> showPage(PAGE_CUSTOMERS, "Manage Customers"));
        JButton viewReport = AppTheme.createWarningButton("📈 View Reports");
        viewReport.addActionListener(e -> showPage(PAGE_REPORTS, "Reports & Analytics"));

        actBtns.add(addVehicle);
        actBtns.add(newRental);
        actBtns.add(addCustomer);
        actBtns.add(viewReport);
        actionsCard.add(actBtns, BorderLayout.CENTER);
        panel.add(actionsCard);
        panel.add(Box.createVerticalStrut(14));

        // ── VEHICLE AVAILABILITY BAR ───────────────────────────────────────────
        JPanel availCard = AppTheme.createCard();
        availCard.setLayout(new BoxLayout(availCard, BoxLayout.Y_AXIS));
        availCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 100));

        JLabel availTitle = AppTheme.createSectionTitle("Vehicle Availability");
        availTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        availCard.add(availTitle);
        availCard.add(Box.createVerticalStrut(12));

        // Progress-style bar
        JPanel barBg = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(226, 232, 240));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                // fill 70% as placeholder
                int fill = (int) (getWidth() * 0.70);
                GradientPaint gp = new GradientPaint(0, 0, AppTheme.SUCCESS, fill, 0, new Color(52, 211, 153));
                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, fill, getHeight(), 8, 8);
                g2.dispose();
            }
        };
        barBg.setMaximumSize(new Dimension(Integer.MAX_VALUE, 16));
        barBg.setPreferredSize(new Dimension(0, 16));
        barBg.setAlignmentX(Component.LEFT_ALIGNMENT);
        availCard.add(barBg);
        availCard.add(Box.createVerticalStrut(6));

        JPanel legendRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 0));
        legendRow.setBackground(AppTheme.CARD_BG);
        legendRow.setAlignmentX(Component.LEFT_ALIGNMENT);
        legendRow.add(legend(AppTheme.SUCCESS, "Available"));
        legendRow.add(legend(AppTheme.DANGER,  "Rented"));
        legendRow.add(legend(AppTheme.WARNING, "Maintenance"));
        availCard.add(legendRow);
        panel.add(availCard);
        panel.add(Box.createVerticalStrut(14));

        // ── RECENT ACTIVITY ──────────────────────────────────────────────────
        JPanel activityCard = AppTheme.createCard();
        activityCard.setLayout(new BorderLayout());
        activityCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 220));

        JPanel actHeader = new JPanel(new BorderLayout());
        actHeader.setBackground(AppTheme.CARD_BG);
        actHeader.add(AppTheme.createSectionTitle("Recent System Activity"), BorderLayout.WEST);
        JButton refreshAct = AppTheme.createSecondaryButton("↺  Refresh");
        actHeader.add(refreshAct, BorderLayout.EAST);

        activityCard.add(actHeader, BorderLayout.NORTH);
        activityCard.add(Box.createVerticalStrut(10));

        String[][] actData = {
            {"System", "Admin dashboard loaded", "Just now"},
            {"Auth",   "Admin login: " + currentUser.getEmail(), "Just now"},
            {"System", "RMI connection established", "Just now"},
        };
        JPanel actList = new JPanel();
        actList.setLayout(new BoxLayout(actList, BoxLayout.Y_AXIS));
        actList.setBackground(AppTheme.CARD_BG);
        for (String[] row : actData) {
            JPanel item = new JPanel(new BorderLayout());
            item.setBackground(AppTheme.CARD_BG);
            item.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, AppTheme.CARD_BORDER),
                BorderFactory.createEmptyBorder(8, 4, 8, 4)
            ));
            item.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

            JLabel dot = new JLabel("●");
            dot.setForeground(AppTheme.PRIMARY);
            dot.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 10));

            JLabel text = new JLabel("[" + row[0] + "]  " + row[1]);
            text.setFont(AppTheme.FONT_BODY);
            text.setForeground(AppTheme.TEXT_PRIMARY);

            JLabel time = new JLabel(row[2]);
            time.setFont(AppTheme.FONT_SMALL);
            time.setForeground(AppTheme.TEXT_MUTED);

            JPanel leftPart = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            leftPart.setBackground(AppTheme.CARD_BG);
            leftPart.add(dot);
            leftPart.add(text);

            item.add(leftPart, BorderLayout.CENTER);
            item.add(time, BorderLayout.EAST);
            actList.add(item);
        }

        activityCard.add(actList, BorderLayout.CENTER);
        panel.add(activityCard);
        panel.add(Box.createVerticalStrut(24));

        return panel;
    }

    private JPanel legend(Color color, String text) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        p.setBackground(AppTheme.CARD_BG);
        JLabel dot = new JLabel("■");
        dot.setForeground(color);
        dot.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        JLabel lbl = new JLabel(text);
        lbl.setFont(AppTheme.FONT_SMALL);
        lbl.setForeground(AppTheme.TEXT_SECONDARY);
        p.add(dot);
        p.add(lbl);
        return p;
    }

    // ── REPORTS PAGE ──────────────────────────────────────────────────────────
    private JPanel buildReportsPage() {
        JPanel page = new JPanel(new BorderLayout());
        page.setBackground(AppTheme.CONTENT_BG);

        JPanel inner = new JPanel();
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
        inner.setBackground(AppTheme.CONTENT_BG);
        inner.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JLabel title = new JLabel("Reports & Analytics");
        title.setFont(AppTheme.FONT_TITLE);
        title.setForeground(AppTheme.TEXT_PRIMARY);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        inner.add(title);
        inner.add(Box.createVerticalStrut(20));

        // Chart placeholder cards
        JPanel chartRow = new JPanel(new GridLayout(1, 2, 14, 0));
        chartRow.setBackground(AppTheme.CONTENT_BG);
        chartRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 240));
        chartRow.add(buildChartPlaceholder("📊", "Monthly Revenue", "Bar chart — connect analytics service"));
        chartRow.add(buildChartPlaceholder("📈", "Rental Trends",   "Line chart — connect analytics service"));
        inner.add(chartRow);
        inner.add(Box.createVerticalStrut(14));

        JPanel chartRow2 = new JPanel(new GridLayout(1, 2, 14, 0));
        chartRow2.setBackground(AppTheme.CONTENT_BG);
        chartRow2.setMaximumSize(new Dimension(Integer.MAX_VALUE, 240));
        chartRow2.add(buildChartPlaceholder("🚗", "Vehicle Usage by Category", "Pie chart placeholder"));
        chartRow2.add(buildChartPlaceholder("💳", "Payment Methods Breakdown",  "Donut chart placeholder"));
        inner.add(chartRow2);
        inner.add(Box.createVerticalStrut(14));

        // Export buttons
        JPanel exportCard = AppTheme.createCard();
        exportCard.setLayout(new BorderLayout());
        exportCard.setMaximumSize(new Dimension(Integer.MAX_VALUE, 90));
        exportCard.add(AppTheme.createSectionTitle("Export Reports"), BorderLayout.NORTH);
        JPanel exportBtns = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        exportBtns.setBackground(AppTheme.CARD_BG);
        JButton csvBtn = AppTheme.createSuccessButton("⬇  Export CSV");
        JButton pdfBtn = AppTheme.createDangerButton("⬇  Export PDF");
        JButton printBtn = AppTheme.createSecondaryButton("🖨  Print Report");
        csvBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "CSV export — connect to your report service.", "Export", JOptionPane.INFORMATION_MESSAGE));
        pdfBtn.addActionListener(e -> JOptionPane.showMessageDialog(this, "PDF export — connect to your report service.", "Export", JOptionPane.INFORMATION_MESSAGE));
        exportBtns.add(csvBtn);
        exportBtns.add(pdfBtn);
        exportBtns.add(printBtn);
        exportCard.add(exportBtns, BorderLayout.CENTER);
        inner.add(exportCard);

        page.add(AppTheme.createScrollPane(inner), BorderLayout.CENTER);
        return page;
    }

    private JPanel buildChartPlaceholder(String icon, String title, String subtitle) {
        JPanel card = AppTheme.createCard();
        card.setLayout(new GridBagLayout());

        JPanel inner = new JPanel();
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
        inner.setBackground(AppTheme.CARD_BG);

        JLabel iconLbl = new JLabel(icon, JLabel.CENTER);
        iconLbl.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 36));
        iconLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel titleLbl = new JLabel(title, JLabel.CENTER);
        titleLbl.setFont(AppTheme.FONT_BODY_BOLD);
        titleLbl.setForeground(AppTheme.TEXT_PRIMARY);
        titleLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subLbl = new JLabel(subtitle, JLabel.CENTER);
        subLbl.setFont(AppTheme.FONT_SMALL);
        subLbl.setForeground(AppTheme.TEXT_MUTED);
        subLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

        inner.add(iconLbl);
        inner.add(Box.createVerticalStrut(8));
        inner.add(titleLbl);
        inner.add(Box.createVerticalStrut(4));
        inner.add(subLbl);
        card.add(inner);
        return card;
    }

    private void doLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?", "Confirm Logout",
            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm == JOptionPane.YES_OPTION) {
            new LoginFrame().setVisible(true);
            dispose();
        }
    }
}

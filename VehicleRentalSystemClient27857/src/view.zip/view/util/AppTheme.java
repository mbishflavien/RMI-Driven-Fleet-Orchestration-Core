package view.util;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.basic.BasicScrollBarUI;

/**
 * AppTheme - Central theme engine for VehicleRentalSystem27857
 * Premium enterprise dark-sidebar / light-content design system.
 */
public class AppTheme {

    // ─── COLOR PALETTE ──────────────────────────────────────────────────────
    public static final Color SIDEBAR_BG        = new Color(15, 23, 42);      // deep navy
    public static final Color SIDEBAR_HOVER     = new Color(30, 41, 59);
    public static final Color SIDEBAR_ACTIVE    = new Color(37, 99, 235);     // vivid blue
    public static final Color SIDEBAR_TEXT      = new Color(148, 163, 184);
    public static final Color SIDEBAR_TEXT_ACTIVE = Color.WHITE;
    public static final Color SIDEBAR_LOGO_BG   = new Color(37, 99, 235);

    public static final Color TOPBAR_BG         = Color.WHITE;
    public static final Color TOPBAR_BORDER      = new Color(226, 232, 240);

    public static final Color CONTENT_BG        = new Color(248, 250, 252);
    public static final Color CARD_BG           = Color.WHITE;
    public static final Color CARD_BORDER       = new Color(226, 232, 240);

    public static final Color PRIMARY           = new Color(37, 99, 235);
    public static final Color PRIMARY_HOVER     = new Color(29, 78, 216);
    public static final Color PRIMARY_LIGHT     = new Color(219, 234, 254);

    public static final Color SUCCESS           = new Color(16, 185, 129);
    public static final Color SUCCESS_LIGHT     = new Color(209, 250, 229);
    public static final Color WARNING           = new Color(245, 158, 11);
    public static final Color WARNING_LIGHT     = new Color(254, 243, 199);
    public static final Color DANGER            = new Color(239, 68, 68);
    public static final Color DANGER_LIGHT      = new Color(254, 226, 226);
    public static final Color INFO              = new Color(6, 182, 212);
    public static final Color INFO_LIGHT        = new Color(207, 250, 254);
    public static final Color PURPLE            = new Color(139, 92, 246);
    public static final Color PURPLE_LIGHT      = new Color(237, 233, 254);

    public static final Color TEXT_PRIMARY      = new Color(15, 23, 42);
    public static final Color TEXT_SECONDARY    = new Color(100, 116, 139);
    public static final Color TEXT_MUTED        = new Color(148, 163, 184);

    public static final Color TABLE_HEADER_BG   = new Color(15, 23, 42);
    public static final Color TABLE_ROW_EVEN    = Color.WHITE;
    public static final Color TABLE_ROW_ODD     = new Color(248, 250, 252);
    public static final Color TABLE_SELECTION   = new Color(219, 234, 254);
    public static final Color TABLE_GRID        = new Color(226, 232, 240);

    public static final Color INPUT_BG          = Color.WHITE;
    public static final Color INPUT_BORDER      = new Color(203, 213, 225);
    public static final Color INPUT_FOCUS       = new Color(37, 99, 235);
    public static final Color INPUT_TEXT        = new Color(15, 23, 42);

    // ─── FONTS ──────────────────────────────────────────────────────────────
    public static final Font  FONT_TITLE        = new Font("Segoe UI", Font.BOLD, 22);
    public static final Font  FONT_SUBTITLE     = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font  FONT_BODY         = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font  FONT_BODY_BOLD    = new Font("Segoe UI", Font.BOLD, 13);
    public static final Font  FONT_SMALL        = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font  FONT_LARGE        = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font  FONT_XLARGE       = new Font("Segoe UI", Font.BOLD, 36);
    public static final Font  FONT_SIDEBAR_ITEM = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font  FONT_SIDEBAR_LOGO = new Font("Segoe UI", Font.BOLD, 14);
    public static final Font  FONT_TABLE_HEADER = new Font("Segoe UI", Font.BOLD, 12);
    public static final Font  FONT_TABLE_CELL   = new Font("Segoe UI", Font.PLAIN, 12);

    // ─── APPLY GLOBAL DEFAULTS ──────────────────────────────────────────────
    public static void applyGlobalDefaults() {
        UIManager.put("Panel.background",           CONTENT_BG);
        UIManager.put("OptionPane.background",      CARD_BG);
        UIManager.put("OptionPane.messageFont",     FONT_BODY);
        UIManager.put("OptionPane.buttonFont",      FONT_BODY_BOLD);
        UIManager.put("Button.font",                FONT_BODY_BOLD);
        UIManager.put("Label.font",                 FONT_BODY);
        UIManager.put("TextField.font",             FONT_BODY);
        UIManager.put("PasswordField.font",         FONT_BODY);
        UIManager.put("ComboBox.font",              FONT_BODY);
        UIManager.put("Table.font",                 FONT_TABLE_CELL);
        UIManager.put("TableHeader.font",           FONT_TABLE_HEADER);
        UIManager.put("ScrollPane.border",          BorderFactory.createEmptyBorder());
    }

    // ─── BUTTON FACTORY ─────────────────────────────────────────────────────
    public static JButton createPrimaryButton(String text) {
        return createStyledButton(text, PRIMARY, PRIMARY_HOVER, Color.WHITE);
    }

    public static JButton createSuccessButton(String text) {
        return createStyledButton(text, SUCCESS, new Color(5, 150, 105), Color.WHITE);
    }

    public static JButton createDangerButton(String text) {
        return createStyledButton(text, DANGER, new Color(185, 28, 28), Color.WHITE);
    }

    public static JButton createWarningButton(String text) {
        return createStyledButton(text, WARNING, new Color(180, 83, 9), Color.WHITE);
    }

    public static JButton createSecondaryButton(String text) {
        return createStyledButton(text, new Color(241, 245, 249), new Color(226, 232, 240), TEXT_PRIMARY);
    }

    /** Convenience overload accepting an ActionListener */
    public static JButton createStyledButton(String text, Color color, java.awt.event.ActionListener action) {
        JButton btn = createStyledButton(text, color, color.darker(), Color.WHITE);
        btn.addActionListener(action);
        return btn;
    }

    private static JButton createStyledButton(String text, final Color normal, final Color hover, Color fg) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hover : normal);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(FONT_BODY_BOLD);
        btn.setForeground(fg);
        btn.setOpaque(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(btn.getPreferredSize().width + 24, 36));
        btn.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        return btn;
    }

    // ─── ICON BUTTON (small square) ─────────────────────────────────────────
    public static JButton createIconButton(String text, Color color) {
        JButton btn = createStyledButton(text, color, color.darker(), Color.WHITE);
        btn.setPreferredSize(new Dimension(32, 32));
        btn.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        return btn;
    }

    // ─── TEXT FIELD FACTORY ─────────────────────────────────────────────────
    public static JTextField createTextField(String placeholder) {
        JTextField field = new JTextField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(INPUT_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        styleInputField(field);
        field.putClientProperty("placeholder", placeholder);
        return field;
    }

    public static JPasswordField createPasswordField() {
        JPasswordField field = new JPasswordField() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(INPUT_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        styleInputField(field);
        return field;
    }

    private static void styleInputField(JComponent field) {
        field.setFont(FONT_BODY);
        field.setForeground(INPUT_TEXT);
        field.setBackground(INPUT_BG);
        field.setOpaque(false);
        field.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(INPUT_BORDER, 8, 1),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)
        ));
        field.setPreferredSize(new Dimension(field.getPreferredSize().width, 38));
    }

    public static JComboBox createComboBox(String[] items) {
        JComboBox combo = new JComboBox(items);
        combo.setFont(FONT_BODY);
        combo.setBackground(INPUT_BG);
        combo.setForeground(INPUT_TEXT);
        combo.setBorder(BorderFactory.createCompoundBorder(
            new RoundedBorder(INPUT_BORDER, 8, 1),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        combo.setPreferredSize(new Dimension(combo.getPreferredSize().width, 38));
        return combo;
    }

    // ─── CARD PANEL ─────────────────────────────────────────────────────────
    public static JPanel createCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // soft shadow
                for (int i = 4; i > 0; i--) {
                    g2.setColor(new Color(0, 0, 0, 5 * i));
                    g2.fillRoundRect(i, i, getWidth() - i * 2, getHeight() - i * 2, 12, 12);
                }
                g2.setColor(CARD_BG);
                g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        return card;
    }

    // ─── SECTION TITLE LABEL ────────────────────────────────────────────────
    public static JLabel createSectionTitle(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_SUBTITLE);
        lbl.setForeground(TEXT_PRIMARY);
        return lbl;
    }

    public static JLabel createMutedLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(FONT_SMALL);
        lbl.setForeground(TEXT_MUTED);
        return lbl;
    }

    // ─── STYLED SCROLL PANE ─────────────────────────────────────────────────
    public static JScrollPane createScrollPane(Component view) {
        JScrollPane sp = new JScrollPane(view);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.setBackground(CONTENT_BG);
        sp.getViewport().setBackground(CONTENT_BG);
        sp.getVerticalScrollBar().setUI(new FlatScrollBarUI());
        sp.getHorizontalScrollBar().setUI(new FlatScrollBarUI());
        sp.getVerticalScrollBar().setUnitIncrement(12);
        return sp;
    }

    // ─── SEPARATOR LINE ─────────────────────────────────────────────────────
    public static JSeparator createSeparator() {
        JSeparator sep = new JSeparator();
        sep.setForeground(CARD_BORDER);
        sep.setBackground(CARD_BORDER);
        return sep;
    }

    // ─── STATUS BADGE ────────────────────────────────────────────────────────
    public static JLabel createStatusBadge(String text) {
        Color bg, fg;
        String upper = text == null ? "" : text.toUpperCase();
        if (upper.contains("AVAILABLE") || upper.contains("PAID") || upper.contains("ACTIVE") || upper.contains("COMPLETED")) {
            bg = SUCCESS_LIGHT; fg = SUCCESS;
        } else if (upper.contains("RENTED") || upper.contains("PENDING") || upper.contains("ONGOING")) {
            bg = WARNING_LIGHT; fg = WARNING;
        } else if (upper.contains("LATE") || upper.contains("OVERDUE") || upper.contains("INACTIVE") || upper.contains("DELETED")) {
            bg = DANGER_LIGHT; fg = DANGER;
        } else {
            bg = INFO_LIGHT; fg = INFO;
        }
        JLabel badge = new JLabel(text, JLabel.CENTER) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        badge.setFont(new Font("Segoe UI", Font.BOLD, 10));
        badge.setForeground(fg);
        badge.setOpaque(false);
        badge.setBorder(BorderFactory.createEmptyBorder(3, 10, 3, 10));
        return badge;
    }

    // ─── INNER CLASSES ───────────────────────────────────────────────────────

    /** Rounded border utility */
    public static class RoundedBorder extends AbstractBorder {
        private final Color color;
        private final int radius;
        private final int thickness;

        public RoundedBorder(Color color, int radius, int thickness) {
            this.color = color;
            this.radius = radius;
            this.thickness = thickness;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(thickness));
            g2.drawRoundRect(x, y, w - 1, h - 1, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(thickness, thickness, thickness, thickness);
        }
    }

    /** Flat minimal scrollbar */
    public static class FlatScrollBarUI extends BasicScrollBarUI {
        @Override
        protected void configureScrollBarColors() {
            thumbColor = new Color(203, 213, 225);
            trackColor = new Color(241, 245, 249);
        }

        @Override
        protected JButton createDecreaseButton(int orientation) { return createZeroButton(); }
        @Override
        protected JButton createIncreaseButton(int orientation) { return createZeroButton(); }

        private JButton createZeroButton() {
            JButton btn = new JButton();
            btn.setPreferredSize(new Dimension(0, 0));
            btn.setMinimumSize(new Dimension(0, 0));
            btn.setMaximumSize(new Dimension(0, 0));
            return btn;
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle thumbBounds) {
            if (thumbBounds.isEmpty()) return;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(thumbColor);
            g2.fillRoundRect(thumbBounds.x + 2, thumbBounds.y + 2,
                             thumbBounds.width - 4, thumbBounds.height - 4, 6, 6);
            g2.dispose();
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle trackBounds) {
            g.setColor(trackColor);
            g.fillRect(trackBounds.x, trackBounds.y, trackBounds.width, trackBounds.height);
        }
    }
}

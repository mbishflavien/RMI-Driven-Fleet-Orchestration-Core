package view;

import view.util.*;
import controller.ClientRegistry;
import model.*;
import service.*;

import java.awt.*;
import java.rmi.registry.Registry;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

/**
 * ManagePaymentsFrame - Premium finance dashboard panel.
 * Embeddable as ManagePaymentsFrame.PaymentsPanel inside AdminDashboardFrame.
 */
public class ManagePaymentsFrame extends javax.swing.JFrame {

    public ManagePaymentsFrame() {
        AppTheme.applyGlobalDefaults();
        setTitle("VRS — Manage Payments");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.CONTENT_BG);
        root.add(new PaymentsPanel(), BorderLayout.CENTER);
        setContentPane(root);
    }

    // ── EMBEDDABLE PANEL ────────────────────────────────────────────────────────
    public static class PaymentsPanel extends JPanel {

        private JTable table;
        private DefaultTableModel tableModel;
        private JTextField txtId, txtRentalId, txtAmountPaid, txtReference;
        private JComboBox<String> cmbMethod, cmbStatus;
        private JLabel lblMsg;

        // KPI labels for live update
        private JLabel kpiTotalRevLbl, kpiTxnCountLbl, kpiAvgLbl, kpiPendingLbl;

        public PaymentsPanel() {
            setLayout(new BorderLayout());
            setBackground(AppTheme.CONTENT_BG);
            buildUI();
            loadPayments();
        }

        private void buildUI() {
            JPanel main = new JPanel(new BorderLayout());
            main.setBackground(AppTheme.CONTENT_BG);
            main.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            // ── PAGE HEADER ─────────────────────────────────────────────────────
            JPanel header = new JPanel(new BorderLayout());
            header.setBackground(AppTheme.CONTENT_BG);
            header.setBorder(BorderFactory.createEmptyBorder(0, 0, 18, 0));

            JLabel pageTitle = new JLabel("Payment Management");
            pageTitle.setFont(AppTheme.FONT_TITLE);
            pageTitle.setForeground(AppTheme.TEXT_PRIMARY);

            JLabel pageSub = new JLabel("Track and manage all rental payment transactions");
            pageSub.setFont(AppTheme.FONT_BODY);
            pageSub.setForeground(AppTheme.TEXT_SECONDARY);

            JPanel titleStack = new JPanel();
            titleStack.setLayout(new BoxLayout(titleStack, BoxLayout.Y_AXIS));
            titleStack.setBackground(AppTheme.CONTENT_BG);
            titleStack.add(pageTitle);
            titleStack.add(Box.createVerticalStrut(2));
            titleStack.add(pageSub);
            header.add(titleStack, BorderLayout.WEST);


            // ── CENTER: form + table ────────────────────────────────────────────
            JPanel centerSection = new JPanel(new BorderLayout(14, 0));
            centerSection.setBackground(AppTheme.CONTENT_BG);
            centerSection.setBorder(BorderFactory.createEmptyBorder(14, 0, 0, 0));

            // ── FORM CARD ────────────────────────────────────────────────────────
            JPanel formCard = AppTheme.createCard();
            formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
            formCard.setPreferredSize(new Dimension(270, 0));

            sectionTitle(formCard, "Payment Details");

            txtId       = new JTextField(); // hidden id
            txtRentalId = formField(formCard, "Rental ID",         "e.g. 12");
            txtAmountPaid = formField(formCard, "Amount Paid ($)",  "e.g. 525.00");
            txtReference  = formField(formCard, "Reference No.",    "TXN-XXXXXX");

            cmbMethod = combo(formCard, "Payment Method",
                new String[]{"CASH", "CREDIT_CARD", "DEBIT_CARD", "BANK_TRANSFER", "MOBILE_MONEY"});
            cmbStatus = combo(formCard, "Payment Status",
                new String[]{"PAID", "PENDING", "REFUNDED", "FAILED"});

            lblMsg = new JLabel(" ");
            lblMsg.setFont(AppTheme.FONT_SMALL);
            lblMsg.setForeground(AppTheme.SUCCESS);
            lblMsg.setAlignmentX(Component.LEFT_ALIGNMENT);
            formCard.add(lblMsg);
            formCard.add(Box.createVerticalStrut(10));

            // Action buttons
            addBtn(formCard, AppTheme.createPrimaryButton("💳  Register Payment"),   e -> addPayment());
            addBtn(formCard, AppTheme.createWarningButton("✏  Update Payment"),      e -> updatePayment());
            addBtn(formCard, AppTheme.createDangerButton("🗑  Delete Payment"),       e -> deletePayment());
            formCard.add(Box.createVerticalStrut(4));
            addBtn(formCard, AppTheme.createSecondaryButton("🧾  Generate Receipt"), e -> generateReceipt());
            addBtn(formCard, AppTheme.createSuccessButton("⬇  Export CSV"),          e -> exportCsv());
            addBtn(formCard, AppTheme.createSecondaryButton("✕  Clear Form"),        e -> clearForm());

            // ── TABLE CARD ────────────────────────────────────────────────────────
            JPanel tableCard = AppTheme.createCard();
            tableCard.setLayout(new BorderLayout());

            String[] cols = {"ID", "Rental ID", "Amount Paid", "Method", "Date", "Status"};
            tableModel = new DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
            table = new JTable(tableModel);
            TableStyler.applyStyle(table);

            // Status column badge
            table.getColumnModel().getColumn(5).setCellRenderer(new TableStyler.StatusBadgeRenderer());

            // Amount column right-aligned
            DefaultTableCellRenderer rightAlign = new DefaultTableCellRenderer();
            rightAlign.setHorizontalAlignment(JLabel.RIGHT);
            table.getColumnModel().getColumn(2).setCellRenderer(new TableStyler.AlternatingRowRenderer() {
                @Override public Component getTableCellRendererComponent(JTable t, Object v,
                        boolean sel, boolean foc, int row, int col) {
                    Component c = super.getTableCellRendererComponent(t, v, sel, foc, row, col);
                    ((JLabel)c).setHorizontalAlignment(JLabel.RIGHT);
                    ((JLabel)c).setForeground(AppTheme.SUCCESS);
                    ((JLabel)c).setFont(AppTheme.FONT_BODY_BOLD);
                    return c;
                }
            });

            int[] colWidths = {50, 80, 110, 120, 160, 100};
            for (int i = 0; i < colWidths.length; i++)
                table.getColumnModel().getColumn(i).setPreferredWidth(colWidths[i]);

            table.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) populateFormFromTable();
            });

            JPanel toolbar = TableStyler.buildTableToolbar(table, tableModel, "Transaction Ledger", true);
            tableCard.add(toolbar, BorderLayout.NORTH);
            tableCard.add(AppTheme.createScrollPane(table), BorderLayout.CENTER);

            centerSection.add(formCard, BorderLayout.WEST);
            centerSection.add(tableCard, BorderLayout.CENTER);

            main.add(header, BorderLayout.NORTH);
            //main.add(kpiStrip, BorderLayout.CENTER);
            // wrap center section so the outer BorderLayout isn't crowded
            JPanel south = new JPanel(new BorderLayout());
            south.setBackground(AppTheme.CONTENT_BG);
            south.add(centerSection, BorderLayout.CENTER);
            main.add(south, BorderLayout.SOUTH);

            // Use a vertical box so KPI + table sit in a scroll
            JPanel scrollContent = new JPanel();
            scrollContent.setLayout(new BoxLayout(scrollContent, BoxLayout.Y_AXIS));
            scrollContent.setBackground(AppTheme.CONTENT_BG);
            scrollContent.add(header);
            scrollContent.add(Box.createVerticalStrut(14));
            //amascrollContent.add(kpiStrip);
            scrollContent.add(Box.createVerticalStrut(14));
            scrollContent.add(centerSection);

            add(AppTheme.createScrollPane(scrollContent), BorderLayout.CENTER);
        }



        // ── DATA LOADING ────────────────────────────────────────────────────────
        private void loadPayments() {
            SwingWorker<List<Payment>, Void> w = new SwingWorker<List<Payment>, Void>() {
                @Override
                protected List<Payment> doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    PaymentService ps = (PaymentService) r.lookup("payment");
                    return ps.displayAllPayments();
                }
                @Override
                protected void done() {
                    try {
                        tableModel.setRowCount(0);
                        List<Payment> list = get();
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                        double totalRev = 0;
                        int pending = 0;
                        for (Payment p : list) {
                            totalRev += p.getAmountPaid();
                            if ("PENDING".equalsIgnoreCase(p.getPaymentStatus())) pending++;
                            tableModel.addRow(new Object[]{
                                p.getPaymentId(),
                                p.getRental() != null ? p.getRental().getRentalId() : "—",
                                String.format("$%.2f", p.getAmountPaid()),
                                p.getPaymentMethod(),
                                p.getPaymentDate() != null ? sdf.format(p.getPaymentDate()) : "—",
                                p.getPaymentStatus()
                            });
                        }
                        // Update KPIs
                        updateKpi(kpiTotalRevLbl, String.format("$%,.2f", totalRev));
                        updateKpi(kpiTxnCountLbl, String.valueOf(list.size()));
                        updateKpi(kpiAvgLbl, list.isEmpty() ? "$0.00" :
                            String.format("$%.2f", totalRev / list.size()));
                        updateKpi(kpiPendingLbl, String.valueOf(pending));
                        msg("Loaded " + list.size() + " payment records.", false);
                    } catch (Exception ex) {
                        msg("Load error: " + ex.getMessage(), true);
                    }
                }
            };
            w.execute();
        }

        private void addPayment() {
            if (txtRentalId.getText().trim().isEmpty()) {
                msg("Rental ID is required.", true); return;
            }
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    PaymentService ps = (PaymentService) r.lookup("payment");
                    return ps.registerPayment(buildPayment(0));
                }
                @Override
                protected void done() {
                    try { get(); msg("Payment registered successfully!", false); clearForm(); loadPayments(); }
                    catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void updatePayment() {
            if (txtId.getText().trim().isEmpty()) { msg("Select a payment to update.", true); return; }
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    PaymentService ps = (PaymentService) r.lookup("payment");
                    return ps.updatePayment(buildPayment(Integer.parseInt(txtId.getText().trim())));
                }
                @Override
                protected void done() {
                    try { get(); msg("Payment updated!", false); loadPayments(); }
                    catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void deletePayment() {
            if (txtId.getText().trim().isEmpty()) { msg("Select a payment.", true); return; }
            int c = JOptionPane.showConfirmDialog(this,
                "Delete payment #" + txtId.getText() + "?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (c != JOptionPane.YES_OPTION) return;
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    PaymentService ps = (PaymentService) r.lookup("payment");
                    Payment p = new Payment();
                    p.setPaymentId(Integer.parseInt(txtId.getText().trim()));
                    return ps.deletePayment(p);
                }
                @Override
                protected void done() {
                    try { get(); msg("Payment deleted.", false); clearForm(); loadPayments(); }
                    catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void generateReceipt() {
            if (txtId.getText().trim().isEmpty()) { msg("Select a payment to generate receipt.", true); return; }
            // Receipt dialog
            JDialog dialog = new JDialog((JFrame) SwingUtilities.getWindowAncestor(this),
                "Payment Receipt", true);
            dialog.setSize(420, 380);
            dialog.setLocationRelativeTo(this);

            JPanel content = new JPanel();
            content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
            content.setBackground(Color.WHITE);
            content.setBorder(BorderFactory.createEmptyBorder(24, 32, 24, 32));

            addReceiptLine(content, "VEHICLE RENTAL SYSTEM", true, 18);
            addReceiptLine(content, "Official Payment Receipt", false, 12);
            content.add(Box.createVerticalStrut(16));
            content.add(dottedSep());
            content.add(Box.createVerticalStrut(12));
            addReceiptLine(content, "Payment ID   :  #" + txtId.getText(), false, 12);
            addReceiptLine(content, "Rental ID    :  #" + txtRentalId.getText(), false, 12);
            addReceiptLine(content, "Amount Paid  :  " + txtAmountPaid.getText(), false, 12);
            addReceiptLine(content, "Method       :  " + cmbMethod.getSelectedItem(), false, 12);
            addReceiptLine(content, "Status       :  " + cmbStatus.getSelectedItem(), false, 12);
            addReceiptLine(content, "Date         :  " + new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date()), false, 12);
            content.add(Box.createVerticalStrut(12));
            content.add(dottedSep());
            content.add(Box.createVerticalStrut(16));
            addReceiptLine(content, "Thank you for choosing VRS!", false, 11);

            JButton printBtn = AppTheme.createPrimaryButton("🖨  Print Receipt");
            printBtn.setAlignmentX(Component.CENTER_ALIGNMENT);
            printBtn.addActionListener(ev -> {
                JOptionPane.showMessageDialog(dialog, "Print functionality — connect to Java PrinterJob.", "Print", JOptionPane.INFORMATION_MESSAGE);
            });
            content.add(Box.createVerticalStrut(16));
            content.add(printBtn);

            dialog.add(content);
            dialog.setVisible(true);
        }

        private void exportCsv() {
            JOptionPane.showMessageDialog(this,
                "CSV export placeholder.\nConnect to your ReportService to generate actual files.",
                "Export CSV", JOptionPane.INFORMATION_MESSAGE);
        }

        // ── HELPERS ──────────────────────────────────────────────────────────────

        private Payment buildPayment(int id) {
            Payment p = new Payment();
            p.setPaymentId(id);
            try { p.setAmountPaid(Double.parseDouble(txtAmountPaid.getText().trim())); } catch (Exception ignored) {}
            p.setPaymentDate(new Date());
            p.setPaymentMethod((String) cmbMethod.getSelectedItem());
            p.setPaymentStatus((String) cmbStatus.getSelectedItem());
            try {
                Rental rental = new Rental();
                rental.setRentalId(Integer.parseInt(txtRentalId.getText().trim()));
                p.setRental(rental);
            } catch (Exception ignored) {}
            return p;
        }

        private void populateFormFromTable() {
            int row = table.getSelectedRow();
            if (row < 0) return;
            int m = table.convertRowIndexToModel(row);
            txtId.setText(tableModel.getValueAt(m, 0).toString());
            txtRentalId.setText(tableModel.getValueAt(m, 1).toString());
            txtAmountPaid.setText(tableModel.getValueAt(m, 2).toString().replace("$", ""));
            String method = tableModel.getValueAt(m, 3).toString();
            String status = tableModel.getValueAt(m, 5).toString();
            selectCombo(cmbMethod, method);
            selectCombo(cmbStatus, status);
        }

        private void selectCombo(JComboBox<String> c, String val) {
            for (int i = 0; i < c.getItemCount(); i++)
                if (c.getItemAt(i).equalsIgnoreCase(val)) { c.setSelectedIndex(i); return; }
        }

        private void clearForm() {
            txtId.setText(""); txtRentalId.setText(""); txtAmountPaid.setText(""); txtReference.setText("");
            cmbMethod.setSelectedIndex(0); cmbStatus.setSelectedIndex(0);
            table.clearSelection(); lblMsg.setText(" ");
        }

        private void msg(String t, boolean error) {
            lblMsg.setText(t);
            lblMsg.setForeground(error ? AppTheme.DANGER : AppTheme.SUCCESS);
        }

        private void updateKpi(JLabel lbl, String val) {
            if (lbl != null) lbl.setText(val);
        }

        /** Locate the large value JLabel inside a KpiCard (it's the 3rd label by font size) */
        private JLabel findValueLabel(KpiCard card) {
            // KpiCard stores value as a field — we return null, KpiCard.setValue() handles it
            return null; // KpiCard.setValue() is the proper API
        }

        private void sectionTitle(JPanel p, String text) {
            JLabel l = AppTheme.createSectionTitle(text);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            l.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
            p.add(l);
        }

        private JTextField formField(JPanel p, String label, String ph) {
            JLabel l = new JLabel(label);
            l.setFont(AppTheme.FONT_BODY_BOLD);
            l.setForeground(AppTheme.TEXT_PRIMARY);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            JTextField tf = AppTheme.createTextField(ph);
            tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            tf.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(l); p.add(Box.createVerticalStrut(4)); p.add(tf); p.add(Box.createVerticalStrut(10));
            return tf;
        }

        private JComboBox<String> combo(JPanel p, String label, String[] items) {
            JLabel l = new JLabel(label);
            l.setFont(AppTheme.FONT_BODY_BOLD);
            l.setForeground(AppTheme.TEXT_PRIMARY);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            JComboBox<String> c = AppTheme.createComboBox(items);
            c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            c.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(l); p.add(Box.createVerticalStrut(4)); p.add(c); p.add(Box.createVerticalStrut(10));
            return c;
        }

        private void addBtn(JPanel p, JButton btn, java.awt.event.ActionListener a) {
            btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            btn.addActionListener(a);
            p.add(btn);
            p.add(Box.createVerticalStrut(6));
        }

        private void addReceiptLine(JPanel p, String text, boolean bold, int size) {
            JLabel l = new JLabel(text, JLabel.CENTER);
            l.setFont(new Font("Monospaced", bold ? Font.BOLD : Font.PLAIN, size));
            l.setForeground(AppTheme.TEXT_PRIMARY);
            l.setAlignmentX(Component.CENTER_ALIGNMENT);
            p.add(l);
            p.add(Box.createVerticalStrut(4));
        }

        private JPanel dottedSep() {
            JPanel sep = new JPanel() {
                @Override
                protected void paintComponent(Graphics g) {
                    super.paintComponent(g);
                    Graphics2D g2 = (Graphics2D) g;
                    g2.setColor(AppTheme.CARD_BORDER);
                    float[] dash = {4f};
                    g2.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, dash, 0f));
                    g2.drawLine(0, 0, getWidth(), 0);
                }
            };
            sep.setBackground(Color.WHITE);
            sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 4));
            sep.setPreferredSize(new Dimension(0, 4));
            return sep;
        }
    }
}

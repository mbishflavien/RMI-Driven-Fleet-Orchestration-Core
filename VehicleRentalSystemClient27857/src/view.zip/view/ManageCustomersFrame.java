package view;

import view.util.*;
import controller.ClientRegistry;
import model.User;
import service.UserService;

import java.awt.*;
import java.rmi.registry.Registry;
import java.util.List;
import javax.swing.*;
import javax.swing.table.*;

/**
 * ManageCustomersFrame - Premium customer management panel.
 */
public class ManageCustomersFrame extends javax.swing.JFrame {

    public ManageCustomersFrame() {
        AppTheme.applyGlobalDefaults();
        setTitle("VRS — Manage Customers");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1100, 750);
        setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.CONTENT_BG);
        root.add(new CustomersPanel(), BorderLayout.CENTER);
        setContentPane(root);
    }

    public static class CustomersPanel extends JPanel {

        private JTable table;
        private DefaultTableModel tableModel;
        private JTextField txtId, txtName, txtEmail, txtPhone;
        private JPasswordField txtPassword;
        private JComboBox<String> cmbRole, cmbStatus;
        private JLabel lblMsg;

        public CustomersPanel() {
            setLayout(new BorderLayout());
            setBackground(AppTheme.CONTENT_BG);
            buildUI();
            loadCustomers();
        }

        private void buildUI() {
            JPanel main = new JPanel(new BorderLayout(14, 0));
            main.setBackground(AppTheme.CONTENT_BG);
            main.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            // Page header
            JPanel header = buildPageHeader("Customer Management", "View and manage all registered users");
            main.add(header, BorderLayout.NORTH);

            // ── FORM CARD ────────────────────────────────────────────────────
            JPanel formCard = AppTheme.createCard();
            formCard.setLayout(new BoxLayout(formCard, BoxLayout.Y_AXIS));
            formCard.setPreferredSize(new Dimension(270, 0));

            addTitle(formCard, "Customer Details");

            txtId       = hiddenField();
            txtName     = field(formCard, "Full Name",     "John Doe");
            txtEmail    = field(formCard, "Email",         "email@example.com");
            txtPhone    = field(formCard, "Phone Number",  "+1-555-0100");

            JLabel passLbl = lbl("Password");
            passLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
            txtPassword = AppTheme.createPasswordField();
            txtPassword.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            txtPassword.setAlignmentX(Component.LEFT_ALIGNMENT);
            formCard.add(passLbl);
            formCard.add(Box.createVerticalStrut(4));
            formCard.add(txtPassword);
            formCard.add(Box.createVerticalStrut(10));

            cmbRole = combo(formCard, "Role", new String[]{"CUSTOMER", "ADMIN"});
            cmbStatus = combo(formCard, "Status", new String[]{"ACTIVE", "INACTIVE"});

            lblMsg = new JLabel(" ");
            lblMsg.setFont(AppTheme.FONT_SMALL);
            lblMsg.setForeground(AppTheme.SUCCESS);
            lblMsg.setAlignmentX(Component.LEFT_ALIGNMENT);
            formCard.add(lblMsg);
            formCard.add(Box.createVerticalStrut(10));

            formCard.add(actionBtn("+ Add Customer",  AppTheme.PRIMARY, e -> addCustomer()));
            formCard.add(Box.createVerticalStrut(6));
            formCard.add(actionBtn("✏  Update",       AppTheme.WARNING, e -> updateCustomer()));
            formCard.add(Box.createVerticalStrut(6));
            formCard.add(actionBtn("🗑  Delete",       AppTheme.DANGER,  e -> deleteCustomer()));
            formCard.add(Box.createVerticalStrut(10));
            formCard.add(actionBtn("✕  Clear",         new Color(100,116,139), e -> clearForm()));

            // ── TABLE CARD ───────────────────────────────────────────────────
            JPanel tableCard = AppTheme.createCard();
            tableCard.setLayout(new BorderLayout());

            String[] cols = {"ID", "Full Name", "Email", "Phone", "Role", "Status"};
            tableModel = new DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };
            table = new JTable(tableModel);
            TableStyler.applyStyle(table);
            table.getColumnModel().getColumn(4).setCellRenderer(new TableStyler.StatusBadgeRenderer());
            table.getColumnModel().getColumn(5).setCellRenderer(new TableStyler.StatusBadgeRenderer());
            int[] widths = {40, 150, 200, 120, 90, 90};
            for (int i = 0; i < widths.length; i++)
                table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);

            table.getSelectionModel().addListSelectionListener(e -> {
                if (!e.getValueIsAdjusting()) populateForm();
            });

            JPanel toolbar = TableStyler.buildTableToolbar(table, tableModel, "Customer Registry", true);
            tableCard.add(toolbar, BorderLayout.NORTH);
            tableCard.add(AppTheme.createScrollPane(table), BorderLayout.CENTER);

            main.add(formCard, BorderLayout.WEST);
            main.add(tableCard, BorderLayout.CENTER);
            add(main, BorderLayout.CENTER);
        }

        private void loadCustomers() {
            SwingWorker<List<User>, Void> w = new SwingWorker<List<User>, Void>() {
                @Override
                protected List<User> doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    UserService us = (UserService) r.lookup("user");
                    return us.displayAllUsers();
                }
                @Override
                protected void done() {
                    try {
                        tableModel.setRowCount(0);
                        for (User u : get()) {
                            tableModel.addRow(new Object[]{
                                u.getUserId(), u.getFullName(), u.getEmail(),
                                u.getPhoneNumber(), u.getRole(), u.getStatus()
                            });
                        }
                        msg("Loaded " + tableModel.getRowCount() + " users.", false);
                    } catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void addCustomer() {
            if (txtName.getText().trim().isEmpty()) { msg("Name is required.", true); return; }
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    UserService us = (UserService) r.lookup("user");
                    User u = buildUser(0);
                    return us.registerUser(u);
                }
                @Override
                protected void done() {
                    try { get(); msg("Customer added!", false); clearForm(); loadCustomers(); }
                    catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void updateCustomer() {
            if (txtId.getText().trim().isEmpty()) { msg("Select a customer first.", true); return; }
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    UserService us = (UserService) r.lookup("user");
                    return us.updateUser(buildUser(Integer.parseInt(txtId.getText().trim())));
                }
                @Override
                protected void done() {
                    try { get(); msg("Customer updated!", false); loadCustomers(); }
                    catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void deleteCustomer() {
            if (txtId.getText().trim().isEmpty()) { msg("Select a customer first.", true); return; }
            int c = JOptionPane.showConfirmDialog(this, "Delete this customer?", "Confirm", JOptionPane.YES_NO_OPTION);
            if (c != JOptionPane.YES_OPTION) return;
            SwingWorker<String, Void> w = new SwingWorker<String, Void>() {
                @Override
                protected String doInBackground() throws Exception {
                    Registry r = ClientRegistry.getRegistry();
                    UserService us = (UserService) r.lookup("user");
                    User u = new User();
                    u.setUserId(Integer.parseInt(txtId.getText().trim()));
                    return us.deleteUser(u);
                }
                @Override
                protected void done() {
                    try { get(); msg("Customer deleted.", false); clearForm(); loadCustomers(); }
                    catch (Exception ex) { msg("Error: " + ex.getMessage(), true); }
                }
            };
            w.execute();
        }

        private void populateForm() {
            int row = table.getSelectedRow();
            if (row < 0) return;
            int m = table.convertRowIndexToModel(row);
            txtId.setText(tableModel.getValueAt(m, 0).toString());
            txtName.setText(tableModel.getValueAt(m, 1).toString());
            txtEmail.setText(tableModel.getValueAt(m, 2).toString());
            txtPhone.setText(tableModel.getValueAt(m, 3).toString());
            String role   = tableModel.getValueAt(m, 4).toString();
            String status = tableModel.getValueAt(m, 5).toString();
            for (int i = 0; i < cmbRole.getItemCount(); i++)
                if (cmbRole.getItemAt(i).equalsIgnoreCase(role)) { cmbRole.setSelectedIndex(i); break; }
            for (int i = 0; i < cmbStatus.getItemCount(); i++)
                if (cmbStatus.getItemAt(i).equalsIgnoreCase(status)) { cmbStatus.setSelectedIndex(i); break; }
        }

        private User buildUser(int id) {
            return new User(id,
                txtName.getText().trim(), txtEmail.getText().trim(),
                new String(txtPassword.getPassword()).trim(),
                txtPhone.getText().trim(),
                (String) cmbRole.getSelectedItem(),
                (String) cmbStatus.getSelectedItem());
        }

        private void clearForm() {
            txtId.setText(""); txtName.setText(""); txtEmail.setText("");
            txtPhone.setText(""); txtPassword.setText("");
            cmbRole.setSelectedIndex(0); cmbStatus.setSelectedIndex(0);
            table.clearSelection(); lblMsg.setText(" ");
        }

        private void msg(String t, boolean error) {
            lblMsg.setText(t);
            lblMsg.setForeground(error ? AppTheme.DANGER : AppTheme.SUCCESS);
        }

        // Helpers
        private JPanel buildPageHeader(String title, String sub) {
            JPanel h = new JPanel(new BorderLayout());
            h.setBackground(AppTheme.CONTENT_BG);
            h.setBorder(BorderFactory.createEmptyBorder(0, 0, 16, 0));
            JLabel t = new JLabel(title); t.setFont(AppTheme.FONT_TITLE); t.setForeground(AppTheme.TEXT_PRIMARY);
            JLabel s = new JLabel(sub);   s.setFont(AppTheme.FONT_BODY);  s.setForeground(AppTheme.TEXT_SECONDARY);
            JPanel stack = new JPanel(); stack.setLayout(new BoxLayout(stack, BoxLayout.Y_AXIS)); stack.setBackground(AppTheme.CONTENT_BG);
            stack.add(t); stack.add(s); h.add(stack, BorderLayout.WEST); return h;
        }

        private void addTitle(JPanel p, String text) {
            JLabel l = AppTheme.createSectionTitle(text);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            l.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
            p.add(l);
        }

        private JTextField field(JPanel p, String label, String ph) {
            JLabel l = lbl(label); l.setAlignmentX(Component.LEFT_ALIGNMENT);
            JTextField tf = AppTheme.createTextField(ph);
            tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); tf.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(l); p.add(Box.createVerticalStrut(4)); p.add(tf); p.add(Box.createVerticalStrut(10));
            return tf;
        }

        private JTextField hiddenField() { return new JTextField(); }

        private JComboBox<String> combo(JPanel p, String label, String[] items) {
            JLabel l = lbl(label); l.setAlignmentX(Component.LEFT_ALIGNMENT);
            JComboBox<String> c = AppTheme.createComboBox(items);
            c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); c.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(l); p.add(Box.createVerticalStrut(4)); p.add(c); p.add(Box.createVerticalStrut(10));
            return c;
        }

        private JButton actionBtn(String text, Color color, java.awt.event.ActionListener a) {
            JButton b = AppTheme.createStyledButton(text, color, a);
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40)); b.setAlignmentX(Component.LEFT_ALIGNMENT);
            return b;
        }

        private JLabel lbl(String t) {
            JLabel l = new JLabel(t); l.setFont(AppTheme.FONT_BODY_BOLD); l.setForeground(AppTheme.TEXT_PRIMARY); return l;
        }
    }
}

package view;

import controller.ClientRegistry;
import model.Rental;
import model.User;
import model.Vehicle;
import service.RentalService;
import service.UserService;
import service.VehicleService;
import view.util.AppTheme;
import view.util.KpiCard;
import view.util.TableStyler;

import java.awt.*;
import java.awt.event.*;
import java.rmi.registry.Registry;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/**
 * ManageRentalsFrame — Premium Rental Management Module.
 *
 * Embed via:  contentArea.add(new ManageRentalsFrame.RentalsPanel(), PAGE_RENTALS);
 *
 * Business rules:
 *   Rental Amount  = rentalDays × dailyRate × (1 − discountPct/100)
 *   Deposit        = rentalAmount × 1.10  (110 %)
 *   Late Penalty   = lateDays × dailyRate × 0.10  (10 % per late day)
 *   Vehicle status AVAILABLE → RENTED on create, RENTED → AVAILABLE on return
 */
public class ManageRentalsFrame extends JFrame {

    public ManageRentalsFrame() {
        AppTheme.applyGlobalDefaults();
        setTitle("VRS — Manage Rentals");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1280, 820);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(null);
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(AppTheme.CONTENT_BG);
        root.add(new RentalsPanel(), BorderLayout.CENTER);
        setContentPane(root);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    //  INNER EMBEDDABLE PANEL
    // ═══════════════════════════════════════════════════════════════════════════
    public static class RentalsPanel extends JPanel {

        private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd");

        // KPI cards
        private KpiCard kpiActive, kpiOverdue, kpiRevMonth, kpiPending;

        // Form inputs
        private JTextField txtRentalId;               // hidden internal ID
        private JComboBox<UserItem>    cmbCustomer;
        private JComboBox<VehicleItem> cmbVehicle;
        private JTextField txtStartDate;
        private JTextField txtReturnDate;
        private JTextField txtTotalDays;              // auto-calc, read-only
        private JTextField txtDailyRate;              // auto-filled from vehicle
        private JTextField txtDiscountPct;
        private JTextField txtRentalAmount;           // auto-calc, read-only
        private JTextField txtDepositAmount;          // auto-calc, read-only
        private JTextField txtLatePenalty;
        private JComboBox<String> cmbStatus;
        private JLabel lblMsg;

        // Table
        private JTable            table;
        private DefaultTableModel tableModel;

        // Cached RMI data for combos
        private List<User>    cachedUsers    = new ArrayList<>();
        private List<Vehicle> cachedVehicles = new ArrayList<>();

        // ───────────────────────────────────────────────────────────────────────
        public RentalsPanel() {
            setLayout(new BorderLayout());
            setBackground(AppTheme.CONTENT_BG);
            buildUI();
            loadComboData();
            loadRentals();
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  UI BUILD
        // ═══════════════════════════════════════════════════════════════════════
        private void buildUI() {
            JPanel scrollRoot = new JPanel();
            scrollRoot.setLayout(new BoxLayout(scrollRoot, BoxLayout.Y_AXIS));
            scrollRoot.setBackground(AppTheme.CONTENT_BG);
            scrollRoot.setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));

            scrollRoot.add(buildPageHeader());
            scrollRoot.add(Box.createVerticalStrut(18));
            scrollRoot.add(buildKpiStrip());
            scrollRoot.add(Box.createVerticalStrut(18));

            JPanel workArea = new JPanel(new BorderLayout(14, 0));
            workArea.setBackground(AppTheme.CONTENT_BG);
            JPanel formCard = buildFormCard();

            JScrollPane formScroll = new JScrollPane(formCard);
            formScroll.setBorder(null);

            formScroll.setHorizontalScrollBarPolicy(
                    JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

            formScroll.getVerticalScrollBar().setUnitIncrement(16);

            formScroll.setPreferredSize(new Dimension(360, 0));

            workArea.add(formScroll, BorderLayout.WEST);
            workArea.add(buildTableCard(), BorderLayout.CENTER);
            scrollRoot.add(workArea);
            scrollRoot.add(Box.createVerticalStrut(24));

            add(AppTheme.createScrollPane(scrollRoot), BorderLayout.CENTER);
        }

        // ── Page header ───────────────────────────────────────────────────────
        private JPanel buildPageHeader() {
            JPanel h = new JPanel(new BorderLayout());
            h.setBackground(AppTheme.CONTENT_BG);
            h.setMaximumSize(new Dimension(Integer.MAX_VALUE, 54));

            JPanel ts = new JPanel();
            ts.setLayout(new BoxLayout(ts, BoxLayout.Y_AXIS));
            ts.setBackground(AppTheme.CONTENT_BG);
            JLabel t1 = new JLabel("Rental Management");
            t1.setFont(AppTheme.FONT_TITLE);
            t1.setForeground(AppTheme.TEXT_PRIMARY);
            JLabel t2 = new JLabel("Create, track and manage all vehicle rental agreements");
            t2.setFont(AppTheme.FONT_BODY);
            t2.setForeground(AppTheme.TEXT_SECONDARY);
            ts.add(t1); ts.add(Box.createVerticalStrut(2)); ts.add(t2);

            JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 6));
            right.setBackground(AppTheme.CONTENT_BG);
            JButton refreshBtn = AppTheme.createSecondaryButton("↺  Refresh");
            refreshBtn.addActionListener(e -> { loadComboData(); loadRentals(); });
            JButton csvBtn = AppTheme.createSecondaryButton("⬇  Export CSV");
            csvBtn.addActionListener(e -> exportPlaceholder("CSV"));
            JButton pdfBtn = AppTheme.createSecondaryButton("⬇  Export PDF");
            pdfBtn.addActionListener(e -> exportPlaceholder("PDF"));
            right.add(csvBtn); right.add(pdfBtn); right.add(refreshBtn);

            h.add(ts,    BorderLayout.WEST);
            h.add(right, BorderLayout.EAST);
            return h;
        }

        // ── KPI strip ────────────────────────────────────────────────────────
        private JPanel buildKpiStrip() {
            kpiActive   = new KpiCard("📋", "Active Rentals",     "—", "Currently ongoing",  AppTheme.PRIMARY);
            kpiOverdue  = new KpiCard("⚠️", "Overdue / Late",     "—", "Past return date",   AppTheme.DANGER);
            kpiRevMonth = new KpiCard("💰", "Revenue This Month", "—", "Rental amounts",     AppTheme.SUCCESS);
            kpiPending  = new KpiCard("⏳", "Pending Returns",    "—", "Not yet returned",   AppTheme.WARNING);
            JPanel strip = KpiCard.buildKpiRow(kpiActive, kpiOverdue, kpiRevMonth, kpiPending);
            strip.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
            return strip;
        }

        // ── Form card ────────────────────────────────────────────────────────
        private JPanel buildFormCard() {
            JPanel card = AppTheme.createCard();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setMinimumSize(new Dimension(270, 0));

            sectionTitle(card, "Rental Details");

            // Hidden ID field (not shown in UI)
            txtRentalId = new JTextField();
            txtRentalId.setVisible(false);
            card.add(txtRentalId);

            // Customer combo
            formLabel(card, "Customer");
            cmbCustomer = new JComboBox<>();
            styleCombo(cmbCustomer);
            card.add(cmbCustomer);
            card.add(vgap(10));

            // Vehicle combo — fires onVehicleSelected()
            formLabel(card, "Vehicle");
            cmbVehicle = new JComboBox<>();
            styleCombo(cmbVehicle);
            cmbVehicle.addActionListener(e -> onVehicleSelected());
            card.add(cmbVehicle);
            card.add(vgap(10));

            // Start / Return dates
            formLabel(card, "Start Date  (yyyy-MM-dd)");
            txtStartDate = formField("e.g.  2024-06-01");
            autoCalcOn(txtStartDate);
            card.add(txtStartDate); card.add(vgap(10));

            formLabel(card, "Return Date  (yyyy-MM-dd)");
            txtReturnDate = formField("e.g.  2024-06-08");
            autoCalcOn(txtReturnDate);
            card.add(txtReturnDate); card.add(vgap(10));

            // ── Auto-calculated section ────────────────────────────────────
            divider(card, "AUTO-CALCULATED");

            formLabel(card, "Total Days");
            txtTotalDays = readOnlyField("0");
            card.add(txtTotalDays); card.add(vgap(8));

            formLabel(card, "Daily Rate ($)");
            txtDailyRate = readOnlyField("0.00");
            card.add(txtDailyRate); card.add(vgap(8));

            formLabel(card, "Discount (%)");
            txtDiscountPct = formField("0");
            autoCalcOn(txtDiscountPct);
            card.add(txtDiscountPct); card.add(vgap(8));

            formLabel(card, "Rental Amount ($)");
            txtRentalAmount = readOnlyField("0.00");
            card.add(txtRentalAmount); card.add(vgap(8));

            formLabel(card, "Deposit — 110% ($)");
            txtDepositAmount = readOnlyField("0.00");
            card.add(txtDepositAmount); card.add(vgap(8));

            formLabel(card, "Late Penalty ($)");
            txtLatePenalty = formField("0.00");
            card.add(txtLatePenalty); card.add(vgap(10));

            // Status
            formLabel(card, "Rental Status");
            cmbStatus = AppTheme.createComboBox(
                    new String[]{"ONGOING", "COMPLETED", "CANCELLED", "OVERDUE"});
            cmbStatus.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            cmbStatus.setAlignmentX(Component.LEFT_ALIGNMENT);
            card.add(cmbStatus); card.add(vgap(12));

            // Message
            lblMsg = new JLabel(" ");
            lblMsg.setFont(AppTheme.FONT_SMALL);
            lblMsg.setForeground(AppTheme.SUCCESS);
            lblMsg.setAlignmentX(Component.LEFT_ALIGNMENT);
            card.add(lblMsg); card.add(vgap(10));

            // ── Action buttons ─────────────────────────────────────────────
            divider(card, "ACTIONS");

            actionBtn(card, AppTheme.createPrimaryButton("＋  Create Rental"),   e -> createRental());
            actionBtn(card, AppTheme.createWarningButton("✏   Update Rental"),   e -> updateRental());
            actionBtn(card, AppTheme.createSuccessButton("🔑  Return Vehicle"),  e -> returnVehicle());
            actionBtn(card, AppTheme.createDangerButton("🗑   Delete Rental"),   e -> deleteRental());
            card.add(vgap(6));
            actionBtn(card, AppTheme.createSecondaryButton("✕   Clear Form"),    e -> clearForm());
            card.add(Box.createVerticalGlue());
            
            return card;
        }

        // ── Table card ───────────────────────────────────────────────────────
        private JPanel buildTableCard() {
            JPanel card = AppTheme.createCard();
            card.setLayout(new BorderLayout(0, 0));

            String[] cols = {
                "ID", "Customer", "Vehicle",
                "Start Date", "Return Date", "Days",
                "Amount ($)", "Deposit ($)", "Penalty ($)", "Status"
            };
            tableModel = new DefaultTableModel(cols, 0) {
                @Override public boolean isCellEditable(int r, int c) { return false; }
            };

            table = new JTable(tableModel);
            TableStyler.applyStyle(table);

            // Status badge on column 9
            table.getColumnModel().getColumn(9)
                 .setCellRenderer(new TableStyler.StatusBadgeRenderer());

            // Money renderers
            table.getColumnModel().getColumn(6).setCellRenderer(new MoneyRenderer(AppTheme.SUCCESS));
            table.getColumnModel().getColumn(7).setCellRenderer(new MoneyRenderer(AppTheme.INFO));
            table.getColumnModel().getColumn(8).setCellRenderer(new PenaltyRenderer());

            // Overdue row highlighter
            table.setDefaultRenderer(Object.class, new OverdueRowRenderer());

            // Column widths
            int[] widths = { 40, 140, 155, 90, 90, 40, 90, 90, 82, 106 };
            for (int i = 0; i < widths.length; i++)
                table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);

            // Row click → populate form
            table.getSelectionModel().addListSelectionListener(ev -> {
                if (!ev.getValueIsAdjusting()) populateFormFromRow();
            });

            JPanel toolbar = TableStyler.buildTableToolbar(
                table, tableModel, "Rental Records", true);

            card.add(toolbar,                          BorderLayout.NORTH);
            card.add(AppTheme.createScrollPane(table), BorderLayout.CENTER);
            card.add(buildTableFooter(),               BorderLayout.SOUTH);
            return card;
        }

        private JPanel buildTableFooter() {
            JPanel f = new JPanel(new FlowLayout(FlowLayout.RIGHT, 16, 8));
            f.setBackground(AppTheme.CARD_BG);
            f.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, AppTheme.CARD_BORDER));
            JLabel hint = new JLabel(
                "ℹ  Click a row to load it into the form   ·   " +
                "Overdue rows are highlighted in red");
            hint.setFont(AppTheme.FONT_SMALL);
            hint.setForeground(AppTheme.TEXT_MUTED);
            f.add(hint);
            return f;
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  DATA LOADING (all on background threads)
        // ═══════════════════════════════════════════════════════════════════════

        private void loadComboData() {
            new SwingWorker<Void, Void>() {
                List<User>    users    = new ArrayList<>();
                List<Vehicle> vehicles = new ArrayList<>();

                @Override protected Void doInBackground() throws Exception {
                    Registry reg = ClientRegistry.getRegistry();
                    users    = ((UserService)    reg.lookup("user")).displayAllUsers();
                    vehicles = ((VehicleService) reg.lookup("vehicle")).displayAllVehicles();
                    return null;
                }

                @Override protected void done() {
                    try {
                        get();
                        cachedUsers    = users;
                        cachedVehicles = vehicles;

                        cmbCustomer.removeAllItems();
                        for (User u : users)
                            cmbCustomer.addItem(new UserItem(u));

                        cmbVehicle.removeAllItems();
                        for (Vehicle v : vehicles)
                            cmbVehicle.addItem(new VehicleItem(v));

                    } catch (InterruptedException | ExecutionException ex) {
                        msg("Could not load combo data: " + cause(ex), true);
                    }
                }
            }.execute();
        }

        private void loadRentals() {
            msg("Loading rentals…", false);
            new SwingWorker<List<Rental>, Void>() {
                @Override protected List<Rental> doInBackground() throws Exception {
                    Registry reg = ClientRegistry.getRegistry();
                    return ((RentalService) reg.lookup("rental")).displayAllRentals();
                }

                @Override protected void done() {
                    try {
                        List<Rental> list = get();
                        fillTable(list);
                        fillKpis(list);
                        msg("Loaded " + list.size() + " rental record(s).", false);
                    } catch (InterruptedException | ExecutionException ex) {
                        msg("Load error: " + cause(ex), true);
                    }
                }
            }.execute();
        }

        private void fillTable(List<Rental> list) {
            tableModel.setRowCount(0);
            for (Rental r : list) {
                String cust = r.getCustomer() != null ? r.getCustomer().getFullName()  : "—";
                String veh  = r.getVehicle()  != null
                    ? r.getVehicle().getBrand() + " " + r.getVehicle().getModel()
                      + " (" + r.getVehicle().getPlateNumber() + ")" : "—";
                tableModel.addRow(new Object[]{
                    r.getRentalId(), cust, veh,
                    r.getStartDate() != null ? SDF.format(r.getStartDate()) : "—",
                    r.getEndDate()   != null ? SDF.format(r.getEndDate())   : "—",
                    r.getRentalDays(),
                    r.getTotalAmount(),
                    r.getDepositAmount(),
                    r.getLatePenalty(),
                    r.getRentalStatus()
                });
            }
        }

        private void fillKpis(List<Rental> list) {
            int active = 0, overdue = 0, pending = 0;
            double revMonth = 0;
            Date now = new Date();
            Calendar cal = Calendar.getInstance();
            int curMon = cal.get(Calendar.MONTH), curYr = cal.get(Calendar.YEAR);

            for (Rental r : list) {
                String st = r.getRentalStatus() == null ? "" : r.getRentalStatus().toUpperCase();
                if ("ONGOING".equals(st))  active++;
                if ("OVERDUE".equals(st))  overdue++;
                if ("ONGOING".equals(st) || "OVERDUE".equals(st)) pending++;
                // also flag ONGOING past end date
                if ("ONGOING".equals(st) && r.getEndDate() != null && r.getEndDate().before(now))
                    overdue++;
                if (r.getStartDate() != null) {
                    cal.setTime(r.getStartDate());
                    if (cal.get(Calendar.MONTH) == curMon && cal.get(Calendar.YEAR) == curYr)
                        revMonth += r.getTotalAmount();
                }
            }

            kpiActive.setValue(String.valueOf(active));
            kpiActive.setTrend(active > 0 ? "▲ " + active + " ongoing" : "None active");
            kpiOverdue.setValue(String.valueOf(overdue));
            kpiOverdue.setTrend(overdue > 0 ? "Requires attention" : "All on time ✓");
            kpiRevMonth.setValue(String.format("$%,.2f", revMonth));
            kpiRevMonth.setTrend("Current month total");
            kpiPending.setValue(String.valueOf(pending));
            kpiPending.setTrend(pending + " awaiting return");
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  FORM ↔ TABLE  BINDING
        // ═══════════════════════════════════════════════════════════════════════

        private void populateFormFromRow() {
            int viewRow = table.getSelectedRow();
            if (viewRow < 0) return;
            int mr = table.convertRowIndexToModel(viewRow);

            txtRentalId.setText(tableModel.getValueAt(mr, 0).toString());

            // Customer combo — match by name fragment
            String custCell = tableModel.getValueAt(mr, 1).toString();
            for (int i = 0; i < cmbCustomer.getItemCount(); i++) {
                if (cmbCustomer.getItemAt(i).toString().contains(custCell.split(" ")[0])) {
                    cmbCustomer.setSelectedIndex(i); break;
                }
            }

            // Vehicle combo — match by plate number in parentheses
            String vehCell = tableModel.getValueAt(mr, 2).toString();
            String plate   = extractPlate(vehCell);
            for (int i = 0; i < cmbVehicle.getItemCount(); i++) {
                if (cmbVehicle.getItemAt(i).toString().contains(plate)) {
                    cmbVehicle.setSelectedIndex(i); break;
                }
            }

            txtStartDate.setText(tableModel.getValueAt(mr, 3).toString());
            txtReturnDate.setText(tableModel.getValueAt(mr, 4).toString());
            txtTotalDays.setText(tableModel.getValueAt(mr, 5).toString());

            double amount  = asDouble(tableModel.getValueAt(mr, 6));
            double deposit = asDouble(tableModel.getValueAt(mr, 7));
            double penalty = asDouble(tableModel.getValueAt(mr, 8));

            txtRentalAmount.setText(fmt(amount));
            txtDepositAmount.setText(fmt(deposit));
            txtLatePenalty.setText(fmt(penalty));
            txtDiscountPct.setText("0");

            pickCombo(cmbStatus, tableModel.getValueAt(mr, 9).toString());
            msg("Rental #" + txtRentalId.getText() + " loaded into form.", false);
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  AUTO-CALCULATION
        // ═══════════════════════════════════════════════════════════════════════

        private void onVehicleSelected() {
            VehicleItem vi = (VehicleItem) cmbVehicle.getSelectedItem();
            if (vi == null) return;
            txtDailyRate.setText(fmt(vi.vehicle.getDailyRate()));
            recalc();
        }

        private void autoCalcOn(JTextField f) {
            f.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                public void insertUpdate(javax.swing.event.DocumentEvent e)  { recalc(); }
                public void removeUpdate(javax.swing.event.DocumentEvent e)  { recalc(); }
                public void changedUpdate(javax.swing.event.DocumentEvent e) { recalc(); }
            });
        }

        /**
         * Business rule engine:
         *   days         = (returnDate − startDate) calendar days
         *   rentalAmount = days × rate × (1 − disc/100)
         *   deposit      = rentalAmount × 1.10
         */
        private void recalc() {
            try {
                Date s = SDF.parse(txtStartDate.getText().trim());
                Date e = SDF.parse(txtReturnDate.getText().trim());
                if (e.before(s)) { clearCalc(); return; }

                long days = (e.getTime() - s.getTime()) / (1000L * 60 * 60 * 24);
                txtTotalDays.setText(String.valueOf(days));

                double rate = dbl(txtDailyRate.getText());
                double disc = dbl(txtDiscountPct.getText());
                if (disc < 0) disc = 0; if (disc > 100) disc = 100;

                double rental  = days * rate * (1.0 - disc / 100.0);
                double deposit = rental * 1.10;

                txtRentalAmount.setText(fmt(rental));
                txtDepositAmount.setText(fmt(deposit));

            } catch (ParseException ignored) { clearCalc(); }
        }

        private void clearCalc() {
            txtTotalDays.setText("0");
            txtRentalAmount.setText("0.00");
            txtDepositAmount.setText("0.00");
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  CRUD ACTIONS
        // ═══════════════════════════════════════════════════════════════════════

        private void createRental() {
            if (!validateForm()) return;
            Rental r = buildRental(0);
            if (r == null) return;
            msg("Creating rental…", false);

            new SwingWorker<String, Void>() {
                @Override protected String doInBackground() throws Exception {
                    Registry reg = ClientRegistry.getRegistry();
                    String res = ((RentalService) reg.lookup("rental")).registerRental(r);
                    // Mark vehicle RENTED
                    VehicleItem vi = (VehicleItem) cmbVehicle.getSelectedItem();
                    if (vi != null) {
                        vi.vehicle.setAvailabilityStatus("RENTED");
                        ((VehicleService) reg.lookup("vehicle")).updateVehicle(vi.vehicle);
                    }
                    return res;
                }
                @Override protected void done() {
                    try {
                        get();
                        msg("✔  Rental created. Vehicle marked RENTED.", false);
                        clearForm(); loadRentals(); loadComboData();
                    } catch (InterruptedException | ExecutionException ex) {
                        msg("Error: " + cause(ex), true);
                    }
                }
            }.execute();
        }

        private void updateRental() {
            String idTxt = txtRentalId.getText().trim();
            if (idTxt.isEmpty()) { msg("Select a rental from the table first.", true); return; }
            int id;
            try { id = Integer.parseInt(idTxt); }
            catch (NumberFormatException e) { msg("Invalid rental ID.", true); return; }

            Rental r = buildRental(id);
            if (r == null) return;
            msg("Updating rental…", false);

            new SwingWorker<String, Void>() {
                @Override protected String doInBackground() throws Exception {
                    return ((RentalService) ClientRegistry.getRegistry().lookup("rental"))
                            .updateRental(r);
                }
                @Override protected void done() {
                    try { get(); msg("✔  Rental #" + id + " updated.", false); loadRentals(); }
                    catch (InterruptedException | ExecutionException ex) { msg("Error: " + cause(ex), true); }
                }
            }.execute();
        }

        /**
         * Return Vehicle workflow:
         *  1. Calculate late penalty (10 % of daily rate per overdue day)
         *  2. Set rental status → COMPLETED
         *  3. Set vehicle availability → AVAILABLE
         */
        private void returnVehicle() {
            String idTxt = txtRentalId.getText().trim();
            if (idTxt.isEmpty()) { msg("Select a rental to process return.", true); return; }
            int id;
            try { id = Integer.parseInt(idTxt); }
            catch (NumberFormatException e) { msg("Invalid rental ID.", true); return; }

            int confirm = JOptionPane.showConfirmDialog(this,
                "<html>Mark Rental <b>#" + id + "</b> as <b>RETURNED</b>?<br><br>"
                + "This will:<br>"
                + "  • Set status → <b>COMPLETED</b><br>"
                + "  • Mark vehicle → <b>AVAILABLE</b><br>"
                + "  • Calculate any late penalty (10%/day)</html>",
                "Confirm Vehicle Return",
                JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) return;

            // Late penalty calculation
            double latePenalty = 0;
            try {
                Date endDate = SDF.parse(txtReturnDate.getText().trim());
                Date today   = new Date();
                double rate  = dbl(txtDailyRate.getText());
                if (today.after(endDate)) {
                    long late = (today.getTime() - endDate.getTime()) / (1000L * 60 * 60 * 24);
                    latePenalty = late * rate * 0.10;
                }
            } catch (ParseException ignored) {}

            final double finalPenalty = latePenalty;
            final Rental r = buildRental(id);
            if (r == null) return;
            r.setRentalStatus("COMPLETED");
            r.setActualReturnDate(new Date());
            r.setLatePenalty(finalPenalty);

            msg("Processing return…", false);

            new SwingWorker<String, Void>() {
                @Override protected String doInBackground() throws Exception {
                    Registry reg = ClientRegistry.getRegistry();
                    String res = ((RentalService) reg.lookup("rental")).updateRental(r);
                    // Free vehicle
                    VehicleItem vi = (VehicleItem) cmbVehicle.getSelectedItem();
                    if (vi != null) {
                        vi.vehicle.setAvailabilityStatus("AVAILABLE");
                        ((VehicleService) reg.lookup("vehicle")).updateVehicle(vi.vehicle);
                    }
                    return res;
                }
                @Override protected void done() {
                    try {
                        get();
                        String pStr = finalPenalty > 0
                            ? String.format("  Late penalty: $%.2f", finalPenalty) : "  No late penalty.";
                        msg("✔  Vehicle returned. Status → COMPLETED." + pStr, false);
                        clearForm(); loadRentals(); loadComboData();
                    } catch (InterruptedException | ExecutionException ex) {
                        msg("Error processing return: " + cause(ex), true);
                    }
                }
            }.execute();
        }

        private void deleteRental() {
            String idTxt = txtRentalId.getText().trim();
            if (idTxt.isEmpty()) { msg("Select a rental to delete.", true); return; }
            int id;
            try { id = Integer.parseInt(idTxt); }
            catch (NumberFormatException e) { msg("Invalid ID.", true); return; }

            int confirm = JOptionPane.showConfirmDialog(this,
                "Permanently delete Rental #" + id + "?\nThis cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) return;

            msg("Deleting…", false);

            new SwingWorker<String, Void>() {
                @Override protected String doInBackground() throws Exception {
                    Rental del = new Rental();
                    del.setRentalId(id);
                    return ((RentalService) ClientRegistry.getRegistry().lookup("rental"))
                            .deleteRental(del);
                }
                @Override protected void done() {
                    try { get(); msg("✔  Rental #" + id + " deleted.", false); clearForm(); loadRentals(); }
                    catch (InterruptedException | ExecutionException ex) { msg("Error: " + cause(ex), true); }
                }
            }.execute();
        }

        private void exportPlaceholder(String format) {
            JOptionPane.showMessageDialog(this,
                format + " export placeholder.\nConnect to your ReportService to generate.",
                "Export " + format, JOptionPane.INFORMATION_MESSAGE);
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  FORM BUILDER / VALIDATION
        // ═══════════════════════════════════════════════════════════════════════

        /** Builds a Rental from all form fields. Returns null if dates are invalid. */
        private Rental buildRental(int id) {
            try {
                Rental r = new Rental();
                r.setRentalId(id);

                UserItem ui = (UserItem) cmbCustomer.getSelectedItem();
                if (ui != null) r.setCustomer(ui.user);

                VehicleItem vi = (VehicleItem) cmbVehicle.getSelectedItem();
                if (vi != null) r.setVehicle(vi.vehicle);

                String sd = txtStartDate.getText().trim();
                String ed = txtReturnDate.getText().trim();
                if (!sd.isEmpty()) r.setStartDate(SDF.parse(sd));
                if (!ed.isEmpty()) r.setEndDate(SDF.parse(ed));

                r.setRentalDays(intOf(txtTotalDays.getText()));
                r.setTotalAmount(dbl(txtRentalAmount.getText()));
                r.setDepositAmount(dbl(txtDepositAmount.getText()));
                r.setLatePenalty(dbl(txtLatePenalty.getText()));
                r.setRentalStatus((String) cmbStatus.getSelectedItem());
                return r;

            } catch (ParseException ex) {
                msg("Invalid date. Use format yyyy-MM-dd.", true);
                return null;
            }
        }

        private boolean validateForm() {
            if (cmbCustomer.getSelectedItem() == null) {
                msg("Please select a customer.", true); return false; }
            if (cmbVehicle.getSelectedItem() == null) {
                msg("Please select a vehicle.", true); return false; }
            if (txtStartDate.getText().trim().isEmpty()) {
                msg("Start date is required.", true); return false; }
            if (txtReturnDate.getText().trim().isEmpty()) {
                msg("Return date is required.", true); return false; }
            VehicleItem vi = (VehicleItem) cmbVehicle.getSelectedItem();
            if (vi != null && "RENTED".equalsIgnoreCase(vi.vehicle.getAvailabilityStatus())) {
                msg("Vehicle is currently RENTED — choose another.", true); return false; }
            return true;
        }

        private void clearForm() {
            txtRentalId.setText("");
            if (cmbCustomer.getItemCount() > 0) cmbCustomer.setSelectedIndex(0);
            if (cmbVehicle.getItemCount()  > 0) cmbVehicle.setSelectedIndex(0);
            txtStartDate.setText(""); txtReturnDate.setText("");
            txtTotalDays.setText("0"); txtDailyRate.setText("0.00");
            txtDiscountPct.setText("0"); txtRentalAmount.setText("0.00");
            txtDepositAmount.setText("0.00"); txtLatePenalty.setText("0.00");
            cmbStatus.setSelectedIndex(0);
            table.clearSelection();
            lblMsg.setText(" ");
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  MICRO-HELPERS  (form building, parsing, formatting)
        // ═══════════════════════════════════════════════════════════════════════

        private void msg(String t, boolean err) {
            lblMsg.setText(t);
            lblMsg.setForeground(err ? AppTheme.DANGER : AppTheme.SUCCESS);
        }

        private void sectionTitle(JPanel p, String text) {
            JLabel l = AppTheme.createSectionTitle(text);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            l.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
            p.add(l);
        }

        private void divider(JPanel p, String label) {
            JPanel row = new JPanel(new BorderLayout(8, 0));
            row.setBackground(AppTheme.CARD_BG);
            row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            row.setBorder(BorderFactory.createEmptyBorder(4, 0, 6, 0));
            JLabel lbl = new JLabel(label);
            lbl.setFont(new Font("Segoe UI", Font.BOLD, 9));
            lbl.setForeground(new Color(100, 116, 139));
            JPanel line = new JPanel();
            line.setBackground(new Color(203, 213, 225));
            line.setPreferredSize(new Dimension(0, 1));
            row.add(lbl,  BorderLayout.WEST);
            row.add(line, BorderLayout.CENTER);
            p.add(row);
        }

        private void formLabel(JPanel p, String text) {
            JLabel l = new JLabel(text);
            l.setFont(AppTheme.FONT_BODY_BOLD);
            l.setForeground(AppTheme.TEXT_PRIMARY);
            l.setAlignmentX(Component.LEFT_ALIGNMENT);
            p.add(l); p.add(Box.createVerticalStrut(3));
        }

        private JTextField formField(String ph) {
            JTextField f = AppTheme.createTextField(ph);
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
            return f;
        }

        private JTextField readOnlyField(String val) {
            JTextField f = new JTextField(val) {
                @Override protected void paintComponent(Graphics g) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2.setColor(new Color(241, 245, 249));
                    g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 8, 8);
                    g2.dispose();
                    super.paintComponent(g);
                }
            };
            f.setEditable(false);
            f.setFont(AppTheme.FONT_BODY_BOLD);
            f.setForeground(AppTheme.PRIMARY);
            f.setOpaque(false);
            f.setBorder(BorderFactory.createCompoundBorder(
                new AppTheme.RoundedBorder(AppTheme.INPUT_BORDER, 8, 1),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)
            ));
            f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            f.setAlignmentX(Component.LEFT_ALIGNMENT);
            return f;
        }

        private <T> void styleCombo(JComboBox<T> c) {
            c.setFont(AppTheme.FONT_BODY);
            c.setBackground(AppTheme.INPUT_BG);
            c.setForeground(AppTheme.INPUT_TEXT);
            c.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            c.setAlignmentX(Component.LEFT_ALIGNMENT);
        }

        private void actionBtn(JPanel p, JButton b, ActionListener a) {
            b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            b.setAlignmentX(Component.LEFT_ALIGNMENT);
            b.addActionListener(a);
            p.add(b); p.add(vgap(7));
        }

        private <T> void pickCombo(JComboBox<T> c, String val) {
            for (int i = 0; i < c.getItemCount(); i++)
                if (c.getItemAt(i).toString().toUpperCase().contains(val.toUpperCase())) {
                    c.setSelectedIndex(i); return;
                }
        }

        private Component vgap(int px) { return Box.createVerticalStrut(px); }

        private String fmt(double d)   { return String.format("%.2f", d); }

        private double dbl(String s) {
            if (s == null) return 0;
            try { return Double.parseDouble(s.trim().replace("$","").replace(",","")); }
            catch (NumberFormatException e) { return 0; }
        }

        private int intOf(String s) {
            if (s == null) return 0;
            try { return Integer.parseInt(s.trim()); }
            catch (NumberFormatException e) { return 0; }
        }

        private double asDouble(Object o) {
            if (o == null) return 0;
            try { return Double.parseDouble(o.toString()); }
            catch (NumberFormatException e) { return 0; }
        }

        private String extractPlate(String s) {
            int a = s.indexOf('('), b = s.indexOf(')');
            return (a >= 0 && b > a) ? s.substring(a + 1, b).trim() : s;
        }

        private String cause(Exception ex) {
            Throwable t = ex;
            while (t.getCause() != null) t = t.getCause();
            return t.getMessage() != null ? t.getMessage() : t.getClass().getSimpleName();
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  INNER CLASSES — Combo wrappers
        // ═══════════════════════════════════════════════════════════════════════

        static class UserItem {
            final User user;
            UserItem(User u) { this.user = u; }
            @Override public String toString() {
                return "[" + user.getUserId() + "]  " + user.getFullName()
                     + "  ·  " + user.getEmail();
            }
        }

        static class VehicleItem {
            final Vehicle vehicle;
            VehicleItem(Vehicle v) { this.vehicle = v; }
            @Override public String toString() {
                boolean avail = "AVAILABLE".equalsIgnoreCase(vehicle.getAvailabilityStatus());
                return (avail ? "✓ " : "✗ ") + vehicle.getBrand() + " " + vehicle.getModel()
                     + " (" + vehicle.getPlateNumber() + ")"
                     + "  $" + String.format("%.0f", vehicle.getDailyRate()) + "/day";
            }
        }

        // ═══════════════════════════════════════════════════════════════════════
        //  INNER CLASSES — Cell renderers
        // ═══════════════════════════════════════════════════════════════════════

        /**
         * OverdueRowRenderer — paints OVERDUE rows and ONGOING-past-due rows in pale red.
         * For all other rows it delegates to the standard alternating renderer.
         */
        class OverdueRowRenderer extends TableStyler.AlternatingRowRenderer {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean isSelected,
                    boolean hasFocus, int row, int col) {

                Component c = super.getTableCellRendererComponent(
                    t, value, isSelected, hasFocus, row, col);

                if (!isSelected) {
                    int mr = t.convertRowIndexToModel(row);
                    String status = tableModel.getValueAt(mr, 9).toString().toUpperCase();
                    boolean isOverdue = status.contains("OVERDUE");

                    // ONGOING but end date is in the past → also overdue
                    if (!isOverdue && "ONGOING".equals(status)) {
                        Object endCell = tableModel.getValueAt(mr, 4);
                        try {
                            isOverdue = SDF.parse(endCell.toString()).before(new Date());
                        } catch (ParseException ignored) {}
                    }

                    if (isOverdue) {
                        c.setBackground(new Color(254, 242, 242));
                        if (c instanceof JLabel)
                            ((JLabel) c).setForeground(new Color(153, 27, 27));
                    }
                }
                return c;
            }
        }

        /** Renders a money column: right-aligned, coloured, formatted with $ sign */
        static class MoneyRenderer extends TableStyler.AlternatingRowRenderer {
            private final Color positiveColor;
            MoneyRenderer(Color positiveColor) { this.positiveColor = positiveColor; }

            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, value, sel, foc, row, col);
                if (c instanceof JLabel) {
                    JLabel l = (JLabel) c;
                    l.setHorizontalAlignment(JLabel.RIGHT);
                    if (!sel) {
                        double v = 0;
                        try { v = Double.parseDouble(value.toString()); } catch (Exception ignored) {}
                        l.setForeground(v > 0 ? positiveColor : AppTheme.TEXT_MUTED);
                        l.setFont(v > 0 ? AppTheme.FONT_BODY_BOLD : AppTheme.FONT_TABLE_CELL);
                        l.setText(v > 0 ? String.format("$%.2f", v) : "—");
                    }
                }
                return c;
            }
        }

        /** Renders the penalty column: red/bold when > 0, muted dash when zero */
        static class PenaltyRenderer extends TableStyler.AlternatingRowRenderer {
            @Override
            public Component getTableCellRendererComponent(
                    JTable t, Object value, boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, value, sel, foc, row, col);
                if (c instanceof JLabel) {
                    JLabel l = (JLabel) c;
                    l.setHorizontalAlignment(JLabel.RIGHT);
                    if (!sel) {
                        double v = 0;
                        try { v = Double.parseDouble(value.toString()); } catch (Exception ignored) {}
                        if (v > 0) {
                            l.setForeground(AppTheme.DANGER);
                            l.setFont(AppTheme.FONT_BODY_BOLD);
                            l.setText(String.format("$%.2f", v));
                        } else {
                            l.setForeground(AppTheme.TEXT_MUTED);
                            l.setFont(AppTheme.FONT_TABLE_CELL);
                            l.setText("—");
                        }
                    }
                }
                return c;
            }
        }

    } // end RentalsPanel
} // end ManageRentalsFrame
